package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.sql.Date;

public class TicketController {

    @FXML private TableView<ticket> ticketTable;
    @FXML private TableColumn<ticket, Integer> TRTicketNumberColumn;
    @FXML private TableColumn<ticket, Integer> TRCustomerNumberColumn;
    @FXML private TableColumn<ticket, String> TRTicketTypeColumn;
    @FXML private TableColumn<ticket, Date> TRDatePurchasedColumn;
    @FXML private TableColumn<ticket, Date> TRDateOfUseColumn;

    // TextFields
    @FXML private TextField txtTRTicketNumber;
    @FXML private TextField txtTRCustomerNumber;
    @FXML private TextField txtTRTicketType;
    @FXML private TextField txtTRDatePurchased;
    @FXML private TextField txtTRDateOfUse;
    @FXML private TextField txtTRSearch;

    private ObservableList<ticket> tickets = FXCollections.observableArrayList();

    // DB Info
    private static final String URL  = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadTicketData();

        ticketTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSel, newSel) -> {
                    if (newSel != null) selectTicket();
                }
        );
    }

    private void setupColumns() {
        TRTicketNumberColumn.setCellValueFactory(new PropertyValueFactory<>("ticket_no"));
        TRCustomerNumberColumn.setCellValueFactory(new PropertyValueFactory<>("customer_no"));
        TRTicketTypeColumn.setCellValueFactory(new PropertyValueFactory<>("ticket_type"));
        TRDatePurchasedColumn.setCellValueFactory(new PropertyValueFactory<>("date_purchased"));
        TRDateOfUseColumn.setCellValueFactory(new PropertyValueFactory<>("date_of_use"));

        ticketTable.setItems(tickets);
    }

    private void loadTicketData() {
        tickets.clear();

        String sql = "SELECT ticket_no, customer_no, ticket_type, date_purchased, date_of_use FROM ticket";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                tickets.add(new ticket(
                        rs.getInt("ticket_no"),
                        rs.getInt("customer_no"),
                        rs.getString("ticket_type"),
                        rs.getDate("date_purchased"),
                        rs.getDate("date_of_use")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void addTicket() {
        String sql = "INSERT INTO ticket (customer_no, ticket_type, date_purchased, date_of_use) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtTRCustomerNumber.getText()));
            ps.setString(2, txtTRTicketType.getText());
            ps.setDate(3, Date.valueOf(txtTRDatePurchased.getText()));
            ps.setDate(4, Date.valueOf(txtTRDateOfUse.getText()));

            ps.executeUpdate();
            loadTicketData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void updateTicket() {
        String sql = "UPDATE ticket SET customer_no=?, ticket_type=?, date_purchased=?, date_of_use=? WHERE ticket_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtTRCustomerNumber.getText()));
            ps.setString(2, txtTRTicketType.getText());
            ps.setString(3, txtTRDatePurchased.getText());
            ps.setString(4, txtTRDateOfUse.getText());
            ps.setInt(5, Integer.parseInt(txtTRTicketNumber.getText()));

            ps.executeUpdate();
            loadTicketData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void deleteTicket() {
        String sql = "DELETE FROM ticket WHERE ticket_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtTRTicketNumber.getText()));
            ps.executeUpdate();

            loadTicketData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void clearFields() {
        txtTRTicketNumber.clear();
        txtTRCustomerNumber.clear();
        txtTRTicketType.clear();
        txtTRDatePurchased.clear();
        txtTRDateOfUse.clear();
    }

    private void selectTicket() {
        ticket t = ticketTable.getSelectionModel().getSelectedItem();
        if (t == null) return;

        txtTRTicketNumber.setText(String.valueOf(t.getTicket_no()));
        txtTRCustomerNumber.setText(String.valueOf(t.getCustomer_no()));
        txtTRTicketType.setText(t.getTicket_type());
        txtTRDatePurchased.setText(t.getDate_purchased().toString());
        txtTRDateOfUse.setText(t.getDate_of_use().toString());
    }

    @FXML
    private void handleSearch() {
        String keyword = txtTRSearch.getText().trim();

        if (keyword.isEmpty()) {
            loadTicketData();
            return;
        }

        tickets.clear();

        String sql =
                "SELECT * FROM ticket WHERE " +
                        "CAST(ticket_no AS CHAR) = ? OR " +
                        "CAST(customer_no AS CHAR) = ? OR " +
                        "ticket_type = ? OR " +
                        "date_purchased = ? OR " +
                        "date_of_use = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            for (int i = 1; i <= 5; i++) ps.setString(i, keyword);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                tickets.add(new ticket(
                        rs.getInt("ticket_no"),
                        rs.getInt("customer_no"),
                        rs.getString("ticket_type"),
                        rs.getDate("date_purchased"),
                        rs.getDate("date_of_use")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
