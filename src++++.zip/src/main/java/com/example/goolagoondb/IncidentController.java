package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate; // Import for safer date handling
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;


public class IncidentController {

    @FXML private TableView<incident> incidentTable;
    @FXML private TableColumn<incident, Integer> IRIncidentNumberColumn;
    @FXML private TableColumn<incident, java.sql.Timestamp> IRDateOfIncidentColumn;
    @FXML private TableColumn<incident, String> IRIncidentDescColumn;
    @FXML private TableColumn<incident, String> IRInjuriesDescColumn;
    @FXML private TableColumn<incident, Boolean> IRReimbursementStatusColumn;
    @FXML private TableColumn<incident, Integer> IREmpNumberColumn;
    @FXML private TableColumn<incident, Integer> IRRideNumberColumn;

    @FXML private TextField txtIRIncidentNumber;
    @FXML private TextField txtIRDateOfIncident;
    @FXML private TextField txtIncidentDescription;
    @FXML private TextField txtInjuriesDescription;
    @FXML private CheckBox chkReimbursementStatus;
    @FXML private TextField txtIREmployeeNumber;
    @FXML private TextField txtIRRideNumber;
    @FXML private TextField txtIRSearch;

    @FXML private Button IRbtnAdd;
    @FXML private Button IRbtnUpdate;
    @FXML private Button IRbtnDelete;
    @FXML private Button IRbtnClear;
    @FXML private Button IRbtnSearch;

    @FXML private TextField txtICSearch;

    @FXML private Button ICbtnAdd;
    @FXML private Button ICbtnUpdate;
    @FXML private Button ICbtnDelete;
    @FXML private Button ICbtnClear;
    @FXML private Button ICbtnSearch;

    // NOTE: The 'incident' class must be defined separately with appropriate getters for all fields.
    private ObservableList<incident> incidents = FXCollections.observableArrayList();

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        // Fix: Ensure all necessary UI elements from FXML are loaded before setupColumns()
        setupColumns();
        loadData();

        incidentTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSel, newSel) -> {
                    if (newSel != null) {
                        selectIncident();
                    }
                }
        );
    }

    private void setupColumns() {
        // FIX 1: Corrected PropertyValueFactory mappings to match the variable names in the 'incident' class.
        // FIX 2: Corrected duplicate column assignments.
        IRIncidentNumberColumn.setCellValueFactory(new PropertyValueFactory<>("incident_no"));
        IRDateOfIncidentColumn.setCellValueFactory(new PropertyValueFactory<>("date_of_incident"));
        IRIncidentDescColumn.setCellValueFactory(new PropertyValueFactory<>("incident_desc"));
        IRInjuriesDescColumn.setCellValueFactory(new PropertyValueFactory<>("injuries_desc"));
        IRReimbursementStatusColumn.setCellValueFactory(new PropertyValueFactory<>("reimbursement_status"));
        IREmpNumberColumn.setCellValueFactory(new PropertyValueFactory<>("employee_no"));
        IRRideNumberColumn.setCellValueFactory(new PropertyValueFactory<>("ride_no")); // Mapped the new column

        incidentTable.setItems(incidents);
    }

    private void loadData() {
        incidents.clear();

        String sql = "SELECT * FROM incident";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                // Fix: Changed rs.getDate("date_of_incident") to rs.getTimestamp for DATETIME handling
                incidents.add(new incident(
                        rs.getInt("incident_no"),
                        rs.getTimestamp("date_of_incident"), // Use Timestamp to properly read DATETIME
                        rs.getString("incident_desc"),
                        rs.getString("injuries_desc"),
                        rs.getBoolean("reimbursement_status"),
                        rs.getInt("employee_no"),
                        rs.getInt("ride_no")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void addIncident() {
        // FIX 3: Added 'ride_no' to the INSERT statement.
        String sql = "INSERT INTO incident (date_of_incident, incident_desc, injuries_desc, reimbursement_status, employee_no, ride_no) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setTimestamp(1, getTimestampFromText(txtIRDateOfIncident.getText()));
            ps.setString(2, txtIncidentDescription.getText());
            ps.setString(3, txtInjuriesDescription.getText());
            ps.setBoolean(4, chkReimbursementStatus.isSelected());

            ps.setInt(5, Integer.parseInt(txtIREmployeeNumber.getText()));
            ps.setInt(6, Integer.parseInt(txtIRRideNumber.getText()));

            ps.executeUpdate();

            loadData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error Adding Incident", "Failed to add incident. Ensure all required fields (Date, Employee #, Ride #) are correctly filled.", Alert.AlertType.ERROR);
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Employee # and Ride # must be valid numbers.", Alert.AlertType.WARNING);
        } catch (DateTimeParseException e) {
            showAlert("Date Error", "Please enter the Date of Incident (D.o.I) in a valid format (YYYY-MM-DD HH:MM:SS).", Alert.AlertType.WARNING);
        }
    }

    @FXML
    private void updateIncident() {
        // FIX 6: Added 'ride_no' to the UPDATE statement.
        String sql = "UPDATE incident SET date_of_incident=?, incident_desc=?, injuries_desc=?, reimbursement_status=?, employee_no=?, ride_no=? WHERE incident_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setTimestamp(1, getTimestampFromText(txtIRDateOfIncident.getText()));
            ps.setString(2, txtIncidentDescription.getText());
            ps.setString(3, txtInjuriesDescription.getText());
            ps.setBoolean(4, chkReimbursementStatus.isSelected());
            ps.setInt(5, Integer.parseInt(txtIREmployeeNumber.getText()));
            ps.setInt(6, Integer.parseInt(txtIRRideNumber.getText()));
            ps.setInt(7, Integer.parseInt(txtIRIncidentNumber.getText()));

            ps.executeUpdate();

            loadData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error Updating Incident", "Failed to update incident. Ensure all required fields are correctly filled and the Incident # exists.", Alert.AlertType.ERROR);
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Incident #, Employee #, and Ride # must be valid numbers.", Alert.AlertType.WARNING);
        } catch (DateTimeParseException e) {
            showAlert("Date Error", "Please enter the Date of Incident (D.o.I) in a valid format (YYYY-MM-DD HH:MM:SS).", Alert.AlertType.WARNING);
        }
    }

    @FXML
    private void deleteIncident() {
        String sql = "DELETE FROM incident WHERE incident_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtIRIncidentNumber.getText()));
            ps.executeUpdate();

            loadData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error Deleting Incident", "Failed to delete incident. Ensure the Incident # is valid.", Alert.AlertType.ERROR);
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Incident # must be a valid number.", Alert.AlertType.WARNING);
        }
    }

    @FXML
    private void clearFields() {
        txtIRIncidentNumber.clear();
        txtIRDateOfIncident.clear();
        txtIncidentDescription.clear();
        txtInjuriesDescription.clear();
        chkReimbursementStatus.setSelected(false);
        txtIREmployeeNumber.clear();
        txtIRRideNumber.clear();
    }

    private void selectIncident() {
        incident i = incidentTable.getSelectionModel().getSelectedItem();
        if (i == null) return;

        txtIRIncidentNumber.setText(String.valueOf(i.getIncident_no()));
        txtIRDateOfIncident.setText(i.getDate_of_incident().toString());
        txtIncidentDescription.setText(i.getIncident_desc());
        txtInjuriesDescription.setText(i.getInjuries_desc());
        chkReimbursementStatus.setSelected(i.isReimbursement_status());
        txtIREmployeeNumber.setText(String.valueOf(i.getEmployee_no()));
        txtIRRideNumber.setText(String.valueOf(i.getRide_no()));
    }

    @FXML
    private void handleSearch() {
        String keyword = txtIRSearch.getText().trim();

        if (keyword.isEmpty()) {
            loadData();
            return;
        }

        incidents.clear();

        String sql = "SELECT * FROM incident WHERE " +
                "CAST(incident_no AS CHAR) = ? OR " +
                "incident_desc LIKE ? OR " +
                "injuries_desc LIKE ? OR " +
                "CAST(employee_no AS CHAR) = ? OR " +
                "CAST(ride_no AS CHAR) = ?"; // Added ride_no search

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, keyword);
            ps.setString(2, "%" + keyword + "%");
            ps.setString(3, "%" + keyword + "%");
            ps.setString(4, keyword);
            ps.setString(5, keyword); // Set ride_no parameter

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                incidents.add(new incident(
                        rs.getInt("incident_no"),
                        rs.getTimestamp("date_of_incident"), // Use Timestamp
                        rs.getString("incident_desc"),
                        rs.getString("injuries_desc"),
                        rs.getBoolean("reimbursement_status"),
                        rs.getInt("employee_no"),
                        rs.getInt("ride_no")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Helper method for safer date/time conversion
    private Timestamp getTimestampFromText(String dateText) throws DateTimeParseException {
        // Assuming date is entered as YYYY-MM-DD HH:MM:SS or just YYYY-MM-DD
        try {
            // Try parsing as full DATETIME
            return Timestamp.valueOf(dateText);
        } catch (IllegalArgumentException e) {
            // Try parsing as DATE
            LocalDate localDate = LocalDate.parse(dateText, DateTimeFormatter.ISO_DATE);
            return Timestamp.valueOf(localDate.atStartOfDay());
        }
    }

    private void showAlert(String title, String content, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}