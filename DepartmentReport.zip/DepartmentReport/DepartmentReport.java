package com.example.goolagoondb;

public class DepartmentReport {

    private int departmentNo;
    private String departmentName;
    private int totalEmployees;
    private double averageSalary;

    public DepartmentReport(int departmentNo, String departmentName, int totalEmployees, double averageSalary) {
        this.departmentNo = departmentNo;
        this.departmentName = departmentName;
        this.totalEmployees = totalEmployees;
        this.averageSalary = averageSalary;
    }

    // Getters and Setters
    public int getDepartmentNo() {
        return departmentNo;
    }

    public void setDepartmentNo(int departmentNo) {
        this.departmentNo = departmentNo;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public int getTotalEmployees() {
        return totalEmployees;
    }

    public void setTotalEmployees(int totalEmployees) {
        this.totalEmployees = totalEmployees;
    }

    public double getAverageSalary() {
        return averageSalary;
    }

    public void setAverageSalary(double averageSalary) {
        this.averageSalary = averageSalary;
    }
}
