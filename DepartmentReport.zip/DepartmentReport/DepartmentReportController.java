package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;

public class DepartmentReportController {

    @FXML private TableView<DepartmentReport> departmentReportTable;
    @FXML private TableColumn<DepartmentReport, Integer> DdeptNoColumn;
    @FXML private TableColumn<DepartmentReport, String> DnameColumn;
    @FXML private TableColumn<DepartmentReport, Integer> DempColumn;
    @FXML private TableColumn<DepartmentReport, Double> DsalaryColumn;

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    private ObservableList<DepartmentReport> departmentReports = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        setupTableColumns();
        loadDepartmentReports();
    }

    private void setupTableColumns() {
        DdeptNoColumn.setCellValueFactory(new PropertyValueFactory<>("departmentNo"));
        DnameColumn.setCellValueFactory(new PropertyValueFactory<>("departmentName"));
        DempColumn.setCellValueFactory(new PropertyValueFactory<>("totalEmployees"));
        DsalaryColumn.setCellValueFactory(new PropertyValueFactory<>("averageSalary"));

        departmentReportTable.setItems(departmentReports);
    }

    private void loadDepartmentReports() {
        String sql = "SELECT d.department_no, d.department_name, " +
                "COUNT(e.employee_no) AS total_employees, " +
                "AVG(e.salary) AS average_salary " +
                "FROM department d " +
                "LEFT JOIN employee e ON d.department_no = e.department_no " +
                "GROUP BY d.department_no, d.department_name";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            departmentReports.clear();

            while (rs.next()) {
                departmentReports.add(new DepartmentReport(
                        rs.getInt("department_no"),
                        rs.getString("department_name"),
                        rs.getInt("total_employees"),
                        rs.getDouble("average_salary")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
