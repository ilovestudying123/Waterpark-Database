module com.example.waterparkdbapp {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.sql;
    requires javafx.base;
    requires javafx.graphics;

    opens com.example.waterparkdbapp to javafx.fxml;
    exports com.example.waterparkdbapp;
}