package com.example.waterparkdbapp;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnector {
    private static final String URL = "jdbc:mysql://localhost:3306/WaterParkDBApp"; // your DB
    private static final String USER = "root";   // replace with your DB username
    private static final String PASSWORD = "12345"; // replace with your DB password

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
