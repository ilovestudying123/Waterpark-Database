package com.example.waterparkdbapp;

import java.sql.SQLException;

public class TestDB {
    public static void main(String[] args) throws SQLException {
        if (DatabaseConnector.getConnection() != null) {
            System.out.println("Connected!");
        } else {
            System.out.println("Connection failed.");
        }
    }
}