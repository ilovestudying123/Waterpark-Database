package com.example.waterparkdbapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;
import java.io.IOException;

public class TransactionsController {

    @FXML
    private Button btnOrderTicket;

    @FXML
    private Button btnRentLocker;

    @FXML
    private Button btnRideMaintenance;

    @FXML
    private Button btnMedicalAssistance;

    @FXML
    private Button btnTVBack;

    @FXML
    private void openOrderTicket(ActionEvent event) throws IOException {
        switchScene(event, "Ticket-Transactions.fxml");
    }

    @FXML
    private void openRentLocker(ActionEvent event) throws IOException {
        switchScene(event, "Locker-Transactions.fxml");
    }

    @FXML
    private void openRideMaintenance(ActionEvent event) throws IOException {
        switchScene(event, "Ride-Maintenance-Transactions.fxml");
    }

    @FXML
        private void openMedicalAssistance(ActionEvent event) throws IOException {
        switchScene(event, "Medical-Assistance-Transactions.fxml");
    }

    @FXML
    private void goBack(ActionEvent event) {
        try {
            switchScene(event, "Main-Menu.fxml"); // Go back to transactions menu
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // Helper method to switch scenes and pass the primaryStage to each controller
    private void switchScene(ActionEvent event, String fxmlFile) throws IOException {
        // Load the FXML file for the target scene
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/waterparkdbapp/" + fxmlFile));

        // Load the scene
        Scene scene = new Scene(loader.load());

        // Get the stage (the current window)
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Retrieve the controller from the FXML loader
        Object controller = loader.getController();

        // Set the new scene and show it
        stage.setScene(scene);
        stage.show();
    }
}
