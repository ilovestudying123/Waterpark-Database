package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;

public class ride_attractionController {

    @FXML private TableView<Customer> customerTable;

    @FXML private TableColumn<Customer, Integer> customerNumberColumn;
    @FXML private TableColumn<Customer, String> lastNameColumn;
    @FXML private TableColumn<Customer, String> firstNameColumn;
    @FXML private TableColumn<Customer, Integer> ageColumn;
    @FXML private TableColumn<Customer, String> phoneColumn;
    @FXML private TableColumn<Customer, String> emailColumn;
    @FXML private TableColumn<Customer, Integer> visitsColumn;
    @FXML private TableColumn<Customer, Boolean> pwdStatusColumn;

    // Textfields
    @FXML private TextField txtCustomerNo;
    @FXML private TextField txtLastName;
    @FXML private TextField txtFirstName;
    @FXML private TextField txtAge;
    @FXML private TextField txtPhone;
    @FXML private TextField txtEmail;
    @FXML private TextField txtVisits;

    @FXML private CheckBox chkPWD;

    private ObservableList<Customer> customers = FXCollections.observableArrayList();

    // Update this with your DB info
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadCustomerData();

        customerTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        selectCustomer();
                    }
                }
        );
    }

    private void setupColumns() {
        customerNumberColumn.setCellValueFactory(new PropertyValueFactory<>("customer_no"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("last_name"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("first_name"));
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone_number"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        visitsColumn.setCellValueFactory(new PropertyValueFactory<>("number_of_visits"));
        pwdStatusColumn.setCellValueFactory(new PropertyValueFactory<>("is_pwd"));
        customerTable.setItems(customers);
    }

    private void loadCustomerData() {
        customers.clear();

        String sql = "SELECT customer_no, last_name, first_name, age, phone_number, email, number_of_visits, is_pwd FROM customer";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                customers.add(new Customer(
                        rs.getInt("customer_no"),
                        rs.getString("last_name"),
                        rs.getString("first_name"),
                        rs.getInt("age"),
                        rs.getString("phone_number"),
                        rs.getString("email"),
                        rs.getInt("number_of_visits"),
                        rs.getBoolean("is_pwd")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void addCustomer() {
        String sql = "INSERT INTO customer (last_name, first_name, age, phone_number, email, number_of_visits, is_pwd) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, txtLastName.getText());
            ps.setString(2, txtFirstName.getText());
            ps.setInt(3, Integer.parseInt(txtAge.getText()));
            ps.setString(4, txtPhone.getText());
            ps.setString(5, txtEmail.getText());
            ps.setInt(6, Integer.parseInt(txtVisits.getText()));
            ps.setBoolean(7, chkPWD.isSelected());

            ps.executeUpdate();

            loadCustomerData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void updateCustomer() {
        String sql = "UPDATE customer SET last_name=?, first_name=?, age=?, phone_number=?, email=?, number_of_visits=?, is_pwd=? WHERE customer_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, txtLastName.getText());
            ps.setString(2, txtFirstName.getText());
            ps.setInt(3, Integer.parseInt(txtAge.getText()));
            ps.setString(4, txtPhone.getText());
            ps.setString(5, txtEmail.getText());
            ps.setInt(6, Integer.parseInt(txtVisits.getText()));
            ps.setBoolean(7, chkPWD.isSelected());
            ps.setInt(8, Integer.parseInt(txtCustomerNo.getText()));

            ps.executeUpdate();
            loadCustomerData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void deleteCustomer() {
        String sql = "DELETE FROM customer WHERE customer_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtCustomerNo.getText()));
            ps.executeUpdate();

            loadCustomerData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void clearFields() {
        txtCustomerNo.clear();
        txtLastName.clear();
        txtFirstName.clear();
        txtAge.clear();
        txtPhone.clear();
        txtEmail.clear();
        txtVisits.clear();
        chkPWD.setSelected(false);
    }

    private void selectCustomer() {
        Customer c = customerTable.getSelectionModel().getSelectedItem();
        if (c == null) return;

        txtCustomerNo.setText(String.valueOf(c.getCustomer_no()));
        txtLastName.setText(c.getLast_name());
        txtFirstName.setText(c.getFirst_name());
        txtAge.setText(String.valueOf(c.getAge()));
        txtPhone.setText(c.getPhone_number());
        txtEmail.setText(c.getEmail());
        txtVisits.setText(String.valueOf(c.getNumber_of_visits()));
        chkPWD.setSelected(c.getIs_pwd());
    }
}