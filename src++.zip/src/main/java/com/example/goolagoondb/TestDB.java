package com.example.goolagoondb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TestDB {
    public static void main(String[] args) {
        try {
            Connection conn = DBConnection.getConnection();

            if (conn == null) {
                System.out.println("Connection failed.");
                return;
            }

            String sql = "SELECT * FROM customer";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("customer_no");
                String last = rs.getString("last_name");
                String first = rs.getString("first_name");
                int phone = rs.getInt("phone_number");
                String email = rs.getString("email");
                int visits = rs.getInt("number_of_visits");
                boolean isPWD = rs.getBoolean("is_PWD");
                int age = rs.getInt("age");

                System.out.println(
                        id + " | " + first + " " + last +
                                " | phone: " + phone +
                                " | email: " + email +
                                " | visits: " + visits +
                                " | PWD: " + isPWD +
                                " | age: " + age
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}