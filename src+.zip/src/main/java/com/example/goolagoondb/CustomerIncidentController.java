package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;

public class CustomerIncidentController {

    @FXML private TableView<customer_incident> customer_incident;
    @FXML private TableColumn<customer_incident, Integer> cirIncidentNumberColumn;
    @FXML private TableColumn<customer_incident, Integer> cirCustomerNumberColumn;

    @FXML private TextField txtCIRSearch;
    @FXML private Button CIRbtnSearch;

    private ObservableList<customer_incident> records = FXCollections.observableArrayList();

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadData();
    }

    private void setupColumns() {
        cirIncidentNumberColumn.setCellValueFactory(new PropertyValueFactory<>("incident_no"));
        cirCustomerNumberColumn.setCellValueFactory(new PropertyValueFactory<>("customer_no"));
        customer_incident.setItems(records);
    }

    private void loadData() {
        records.clear();

        String sql = "SELECT incident_no, customer_no FROM customer_incident";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                records.add(new customer_incident(
                        rs.getInt("incident_no"),
                        rs.getInt("customer_no")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSearch() {
        String keyword = txtCIRSearch.getText().trim();

        if (keyword.isEmpty()) {
            loadData();
            return;
        }

        records.clear();

        String sql = "SELECT * FROM customer_incident WHERE " +
                "CAST(incident_no AS CHAR) = ? OR " +
                "CAST(customer_no AS CHAR) = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, keyword);
            ps.setString(2, keyword);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                records.add(new customer_incident(
                        rs.getInt("incident_no"),
                        rs.getInt("customer_no")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}