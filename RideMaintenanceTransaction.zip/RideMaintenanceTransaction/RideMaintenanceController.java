package com.example.goolagoondb;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;

public class RideMaintenanceController {

    @FXML private ComboBox<RideAttraction> cmbSelectRide;

    @FXML private TextField txtRMPHLevel;
    @FXML private TextField txtRMChlorineLevel;
    @FXML private TextField txtRMWaterTemperature;
    @FXML private TextField txtRMViolationCount;
    @FXML private TextField txtRMViolationDescription;

    @FXML private Label lblOutput;

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    // Load rides into ComboBox on start
    @FXML
    public void initialize() {
        loadRides();
    }

    private void loadRides() {
        String sql = "SELECT * FROM ride_attraction";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                RideAttraction r = new RideAttraction(
                        rs.getInt("ride_no"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDate("date_of_inspection"),
                        rs.getInt("ride_capacity"),
                        rs.getInt("height_requirement"),
                        rs.getString("ticket_requirement"),
                        rs.getString("status")
                );
                cmbSelectRide.getItems().add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Step 1: Begin inspection → Set ride DOWN
    @FXML
    private void beginInspection(ActionEvent event) {

        RideAttraction selected = cmbSelectRide.getValue();

        if (selected == null) {
            lblOutput.setText("Select a ride first!");
            return;
        }

        String sql = "UPDATE ride_attraction SET status = 'Down' WHERE ride_no = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, selected.getRide_no());
            ps.executeUpdate();

            lblOutput.setText("Ride marked as DOWN. Enter inspection details.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Step 2: Finish inspection → Insert quality_inspection + update date_of_inspection
    @FXML
    private void finishMaintenance(ActionEvent event) {

        RideAttraction selected = cmbSelectRide.getValue();

        if (selected == null) {
            lblOutput.setText("No ride selected.");
            return;
        }

        try {
            int ph = Integer.parseInt(txtRMPHLevel.getText());
            int chlorine = Integer.parseInt(txtRMChlorineLevel.getText());
            int waterTemp = Integer.parseInt(txtRMWaterTemperature.getText());
            int violationCount = Integer.parseInt(txtRMViolationCount.getText());
            String violationDesc = txtRMViolationDescription.getText();

            LocalDate today = LocalDate.now();

            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            conn.setAutoCommit(false);

            // INSERT INTO quality_inspection
            String insertInspection =
                    "INSERT INTO quality_inspection (date_of_inspection, ride_no, ph_level, chlorine_level, water_temp, violation_count, violation_desc) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps1 = conn.prepareStatement(insertInspection);
            ps1.setDate(1, Date.valueOf(today));
            ps1.setInt(2, selected.getRide_no());
            ps1.setInt(3, ph);
            ps1.setInt(4, chlorine);
            ps1.setInt(5, waterTemp);
            ps1.setInt(6, violationCount);
            ps1.setString(7, violationDesc);
            ps1.executeUpdate();

            // UPDATE ride status + date
            String updateRide =
                    "UPDATE ride_attraction SET date_of_inspection = ?, status = 'Operational' WHERE ride_no = ?";

            PreparedStatement ps2 = conn.prepareStatement(updateRide);
            ps2.setDate(1, Date.valueOf(today));
            ps2.setInt(2, selected.getRide_no());
            ps2.executeUpdate();

            conn.commit();
            conn.close();

            lblOutput.setText("Inspection saved! Ride is now OPERATIONAL.");
            clearFields();

        } catch (Exception e) {
            lblOutput.setText("Error: Invalid input!");
            e.printStackTrace();
        }
    }

    private void clearFields() {
        txtRMPHLevel.clear();
        txtRMChlorineLevel.clear();
        txtRMWaterTemperature.clear();
        txtRMViolationCount.clear();
        txtRMViolationDescription.clear();
    }

    // Back button
    @FXML
    private void goBack(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/goolagoondb/Transactions-View.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
