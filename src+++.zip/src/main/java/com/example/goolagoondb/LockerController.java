package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;

public class LockerController {

    @FXML private TableView<locker> lockerTable;
    @FXML private TableColumn<locker, Integer> LRLockerNumberColumn;
    @FXML private TableColumn<locker, Integer> LRTicketNumberColumn;
    @FXML private TableColumn<locker, String> LRSizeColumn;
    @FXML private TableColumn<locker, Boolean> LRAvailabilityStatusColumn;

    @FXML private TextField txtLRLockerNumber;
    @FXML private TextField txtLRTicketNumber;
    @FXML private MenuButton mnbtnSize;
    @FXML private MenuItem mnSmall;
    @FXML private MenuItem mnMedium;
    @FXML private MenuItem mnLarge;
    @FXML private CheckBox chkAvailabilityStatus;

    @FXML private TextField txtLRSearch;

    @FXML private Button LRbtnAdd;
    @FXML private Button LRbtnUpdate;
    @FXML private Button LRbtnDelete;
    @FXML private Button LRbtnClear;
    @FXML private Button LRbtnSearch;

    private String selectedSize = null;

    private ObservableList<locker> lockers = FXCollections.observableArrayList();

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        setupMenuButtons();
        loadData();

        lockerTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSel, newSel) -> {
                    if (newSel != null) {
                        selectLocker();
                    }
                }
        );
    }

    private void setupColumns() {
        LRLockerNumberColumn.setCellValueFactory(new PropertyValueFactory<>("locker_no"));
        LRTicketNumberColumn.setCellValueFactory(new PropertyValueFactory<>("ticket_no"));
        LRSizeColumn.setCellValueFactory(new PropertyValueFactory<>("size"));
        LRAvailabilityStatusColumn.setCellValueFactory(new PropertyValueFactory<>("availability_status"));

        lockerTable.setItems(lockers);
    }

    private void setupMenuButtons() {
        mnSmall.setOnAction(e -> {
            mnbtnSize.setText("Small");
            selectedSize = "S";
        });

        mnMedium.setOnAction(e -> {
            mnbtnSize.setText("Medium");
            selectedSize = "M";
        });

        mnLarge.setOnAction(e -> {
            mnbtnSize.setText("Large");
            selectedSize = "L";
        });
    }

    private void loadData() {
        lockers.clear();

        String sql = "SELECT * FROM locker";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                lockers.add(new locker(
                        rs.getInt("locker_no"),
                        rs.getBoolean("availability_status"),
                        rs.getString("size"),
                        rs.getInt("ticket_no")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void addLocker() {
        String sql = "INSERT INTO locker (availability_status, size, ticket_no) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBoolean(1, chkAvailabilityStatus.isSelected());
            ps.setString(2, selectedSize);
            ps.setString(3, txtLRTicketNumber.getText().isEmpty() ? null : txtLRTicketNumber.getText());

            ps.executeUpdate();

            loadData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void updateLocker() {
        String sql = "UPDATE locker SET availability_status=?, size=?, ticket_no=? WHERE locker_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBoolean(1, chkAvailabilityStatus.isSelected());
            ps.setString(2, selectedSize);
            ps.setString(3, txtLRTicketNumber.getText().isEmpty() ? null : txtLRTicketNumber.getText());
            ps.setInt(4, Integer.parseInt(txtLRLockerNumber.getText()));

            ps.executeUpdate();

            loadData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void deleteLocker() {
        String sql = "DELETE FROM locker WHERE locker_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtLRLockerNumber.getText()));
            ps.executeUpdate();

            loadData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void clearFields() {
        txtLRLockerNumber.clear();
        txtLRTicketNumber.clear();
        chkAvailabilityStatus.setSelected(false);
        mnbtnSize.setText("Size");
        selectedSize = null;
    }

    private void selectLocker() {
        locker l = lockerTable.getSelectionModel().getSelectedItem();
        if (l == null) return;

        txtLRLockerNumber.setText(String.valueOf(l.getLocker_no()));
        chkAvailabilityStatus.setSelected(l.getAvailability_status());
        txtLRTicketNumber.setText(l.getTicket_no() == null ? "" : String.valueOf(l.getTicket_no()));

        switch (l.getSize()) {
            case "S": mnbtnSize.setText("Small"); break;
            case "M": mnbtnSize.setText("Medium"); break;
            case "L": mnbtnSize.setText("Large"); break;
        }

        selectedSize = l.getSize();
    }

    @FXML
    private void handleSearch() {
        String keyword = txtLRSearch.getText().trim();

        if (keyword.isEmpty()) {
            loadData();
            return;
        }

        lockers.clear();

        String sql = "SELECT * FROM locker WHERE " +
                "CAST(locker_no AS CHAR) = ? OR " +
                "CAST(ticket_no AS CHAR) = ? OR " +
                "size = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, keyword);
            ps.setString(2, keyword);
            ps.setString(3, keyword.toUpperCase());

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lockers.add(new locker(
                        rs.getInt("locker_no"),
                        rs.getBoolean("availability_status"),
                        rs.getString("size"),
                        rs.getInt("ticket_no")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
