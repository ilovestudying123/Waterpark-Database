package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;

public class DepartmentController {

    @FXML private TableView<department> DepartmentTable;
    @FXML private TableColumn<department, Integer> departmentNumberColumn;
    @FXML private TableColumn<department, String> departmentNameColumn;
    @FXML private TableColumn<department, Integer> departmentManagerNumberColumn;

    @FXML private TextField txtDRName;
    @FXML private TextField txtDRDeptNumber;
    @FXML private TextField txtDRManagerNumber;
    @FXML private TextField txtDRSearch;

    @FXML private Button DRbtnAdd;
    @FXML private Button DRbtnUpdate;
    @FXML private Button DRbtnDelete;
    @FXML private Button DRbtnClear;
    @FXML private Button DRbtnSearch;

    private ObservableList<department> departments = FXCollections.observableArrayList();

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadData();

        DepartmentTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        selectDepartment();
                    }
                }
        );
    }

    private void setupColumns() {
        departmentNumberColumn.setCellValueFactory(new PropertyValueFactory<>("department_no"));
        departmentNameColumn.setCellValueFactory(new PropertyValueFactory<>("department_name"));
        departmentManagerNumberColumn.setCellValueFactory(new PropertyValueFactory<>("manager_no"));
        DepartmentTable.setItems(departments);
    }

    private void loadData() {
        departments.clear();

        String sql = "SELECT department_no, department_name, manager_no FROM department";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                departments.add(new department(
                        rs.getInt("department_no"),
                        rs.getString("department_name"),
                        rs.getInt("manager_no")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void addDepartment() {
        String sql = "INSERT INTO department (department_no, department_name, manager_no) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtDRDeptNumber.getText()));
            ps.setString(2, txtDRName.getText());
            ps.setInt(3, Integer.parseInt(txtDRManagerNumber.getText()));

            ps.executeUpdate();

            loadData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void updateDepartment() {
        String sql = "UPDATE department SET department_name=?, manager_no=? WHERE department_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, txtDRName.getText());
            ps.setInt(2, Integer.parseInt(txtDRManagerNumber.getText()));
            ps.setInt(3, Integer.parseInt(txtDRDeptNumber.getText()));

            ps.executeUpdate();
            loadData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void deleteDepartment() {
        String sql = "DELETE FROM department WHERE department_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtDRDeptNumber.getText()));
            ps.executeUpdate();

            loadData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void clearFields() {
        txtDRDeptNumber.clear();
        txtDRName.clear();
        txtDRManagerNumber.clear();
    }

    private void selectDepartment() {
        department d = DepartmentTable.getSelectionModel().getSelectedItem();
        if (d == null) return;

        txtDRDeptNumber.setText(String.valueOf(d.getDepartment_no()));
        txtDRName.setText(d.getDepartment_name());
        txtDRManagerNumber.setText(String.valueOf(d.getManager_no()));
    }

    @FXML
    private void handleSearch() {
        String keyword = txtDRSearch.getText().trim();

        if (keyword.isEmpty()) {
            loadData(); // Reload all
            return;
        }

        departments.clear();

        String sql = "SELECT * FROM department WHERE " +
                "CAST(department_no AS CHAR) = ? OR " +
                "department_name LIKE ? OR " +
                "CAST(manager_no AS CHAR) = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, keyword);
            ps.setString(2, "%" + keyword + "%");
            ps.setString(3, keyword);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                departments.add(new department(
                        rs.getInt("department_no"),
                        rs.getString("department_name"),
                        rs.getInt("manager_no")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}