package com.example.goolagoondb;

public class MainController {
}
