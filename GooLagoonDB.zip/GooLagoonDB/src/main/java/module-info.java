module com.example.goolagoondb {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.sql;
    requires java.desktop;

    opens com.example.goolagoondb to javafx.fxml;
    exports com.example.goolagoondb;
}