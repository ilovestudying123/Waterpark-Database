package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import javafx.scene.control.Alert;

import java.sql.*;
import java.sql.Date;

public class EmployeeRoleController {

    @FXML private TableView<EmpRole> EmployeeRoleTable;
    @FXML private TableColumn<EmpRole, Integer> employeeRoleNumberColumn;
    @FXML private TableColumn<EmpRole, String> employeeRoleTitle;
    @FXML private TableColumn<EmpRole, Date> employeeRoleFromDate;
    @FXML private TableColumn<EmpRole, Date> employeeRoleToDate;


    // Textfields
    @FXML private TextField txtERREmpID;
    @FXML private TextField txtERRTitle;
    @FXML private TextField txtERRFromDate;
    @FXML private TextField txtERRToDate;

    @FXML private TextField txtERRSearch;

    private ObservableList<EmpRole> empRoles = FXCollections.observableArrayList();

    // DB SETUP
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadEmpRoleData();

        EmployeeRoleTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        selectEmpRole();
                    }
                }
        );
    }

    private void setupColumns() {
        employeeRoleNumberColumn.setCellValueFactory(new PropertyValueFactory<>("employee_no"));
        employeeRoleTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        employeeRoleFromDate.setCellValueFactory(new PropertyValueFactory<>("from_date"));
        employeeRoleToDate.setCellValueFactory(new PropertyValueFactory<>("to_date"));

        EmployeeRoleTable.setItems(empRoles);
    }

    // Renamed method and updated logic to load 'emp_role' data
    private void loadEmpRoleData() {
        empRoles.clear();

        // SQL query now selects from the emp_role table
        String sql = "SELECT employee_no, title, from_date, to_date FROM emp_role";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                // Instantiate EmpRole model
                empRoles.add(new EmpRole(
                        rs.getInt("employee_no"),
                        rs.getString("title"),
                        rs.getDate("from_date"),
                        rs.getDate("to_date") // to_date can be null
                ));
            }

        } catch (SQLException e) {
            System.err.println("Failed to load Employee Role data:");
            e.printStackTrace();
        }
    }

    // ================================
    // ADD EMPLOYEE ROLE ASSIGNMENT
    // ================================
    @FXML
    private void addEmpRole() {
        String sql = "INSERT INTO emp_role (employee_no, title, from_date, to_date) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // --- Input Validation ---
            String empIdText = txtERREmpID.getText().trim();
            String titleText = txtERRTitle.getText().trim();
            String fromDateText = txtERRFromDate.getText().trim();
            String toDateText = txtERRToDate.getText().trim();

            if (empIdText.isEmpty() || titleText.isEmpty() || fromDateText.isEmpty()) {
                showAlert("Missing Fields", "Employee #, Title, and From Date are required.");
                return;
            }

            // --- Ensures employee exists (FK) ---
            if (!employeeExists(Integer.parseInt(empIdText))) {
                showAlert("Invalid Employee", "Employee #" + empIdText + " does not exist.");
                return;
            }

            // --- Set SQL parameters ---
            ps.setInt(1, Integer.parseInt(empIdText));    // employee_no
            ps.setString(2, titleText);                   // title
            ps.setDate(3, Date.valueOf(fromDateText));    // from_date

            if (toDateText.isEmpty()) {
                ps.setNull(4, Types.DATE);
            } else {
                ps.setDate(4, Date.valueOf(toDateText));  // to_date
            }

            ps.executeUpdate();

            loadEmpRoleData();
            clearFields();
            showAlert("Success", "Employee role added.");

        } catch (SQLException e) {
            showAlert("SQL Error", "Failed to add employee role.\nCheck for duplicate (employee_no, from_date).");
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            showAlert("Input Error", "Dates must be in YYYY-MM-DD format.");
        }
    }

    // ================================
    // UPDATE EMPLOYEE ROLE ASSIGNMENT
    // Assumes update means changing the to_date for an existing role (PK: emp_no, from_date)
    // ================================
    @FXML
    private void updateEmpRole() {
        String sql = "UPDATE emp_role SET to_date=?, title=? WHERE employee_no=? AND from_date=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String empIdText = txtERREmpID.getText().trim();
            String titleText = txtERRTitle.getText().trim();
            String fromDateText = txtERRFromDate.getText().trim();
            String toDateText = txtERRToDate.getText().trim();

            if (empIdText.isEmpty() || fromDateText.isEmpty()) {
                showAlert("Missing Fields", "Employee # and From Date are required to update a role.");
                return;
            }

            if (!employeeExists(Integer.parseInt(empIdText))) {
                showAlert("Invalid Employee", "Employee #" + empIdText + " does not exist.");
                return;
            }

            if (toDateText.isEmpty()) ps.setNull(1, Types.DATE);
            else ps.setDate(1, Date.valueOf(toDateText));

            ps.setString(2, titleText);

            ps.setInt(3, Integer.parseInt(empIdText));
            ps.setDate(4, Date.valueOf(fromDateText));

            int rows = ps.executeUpdate();

            if (rows == 0) {
                showAlert("Not Found", "No role found for this Employee # and From Date.");
                return;
            }

            // 🔥🔥 SYNC emp_role → employee.job_title (only if CURRENT role)
            if (toDateText.isEmpty()) {
                syncEmployeeJobTitle(Integer.parseInt(empIdText), titleText);
            }

            loadEmpRoleData();
            clearFields();
            showAlert("Updated", "Employee role updated successfully.");

        } catch (SQLException e) {
            showAlert("SQL Error", "Failed to update employee role.");
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            showAlert("Input Error", "Dates must be in YYYY-MM-DD format.");
        }
    }

    // ================================
    // DELETE EMPLOYEE ROLE ASSIGNMENT
    // Deletes an assignment identified by its composite primary key (emp_no, from_date)
    // ================================
    @FXML
    private void deleteEmpRole() {
        String sql = "DELETE FROM emp_role WHERE employee_no=? AND from_date=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // --- Input Validation and Parsing ---
            String empIdText = txtERREmpID.getText();
            String fromDateText = txtERRFromDate.getText();

            if (empIdText.isEmpty() || fromDateText.isEmpty()) {
                System.err.println("Error: Please select a row or fill in Employee ID and From Date to delete.");
                return;
            }

            // Composite Primary Key parameters
            ps.setInt(1, Integer.parseInt(empIdText));
            ps.setDate(2, Date.valueOf(fromDateText));

            ps.executeUpdate();

            loadEmpRoleData();
            clearFields();

        } catch (SQLException e) {
            System.err.println("Failed to delete Employee Role assignment. Check if record exists.");
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            System.err.println("Input format error: Please ensure valid data is entered or selected.");
            e.printStackTrace();
        }
    }

    // ================================
    // CLEAR FIELDS (Updated to correct text fields)
    // ================================
    @FXML
    private void clearFields() {
        txtERREmpID.clear();
        txtERRTitle.clear();
        txtERRFromDate.clear();
        txtERRToDate.clear();
        txtERRSearch.clear();
    }

    // ================================
    // SELECT EMPLOYEE ROLE FROM TABLE (Updated to correct text fields and model getters)
    // ================================
    private void selectEmpRole() {
        EmpRole role = EmployeeRoleTable.getSelectionModel().getSelectedItem();
        if (role == null) return;

        txtERREmpID.setText(String.valueOf(role.getEmployee_no()));
        txtERRTitle.setText(role.getTitle());
        txtERRFromDate.setText(role.getFrom_date().toString());

        // Handle nullable to_date
        if (role.getTo_date() != null) {
            txtERRToDate.setText(role.getTo_date().toString());
        } else {
            txtERRToDate.clear();
        }
    }

    // ================================
    // SEARCH EMPLOYEE ROLE ASSIGNMENTS
    // ================================
    @FXML
    private void handleSearch() {
        String keyword = txtERRSearch.getText().trim();

        if (keyword.isEmpty()) {
            loadEmpRoleData();
            return;
        }

        empRoles.clear();

        // Search for keyword across employee #, title, and dates
        String sql =
                "SELECT * FROM emp_role WHERE " +
                        "CAST(employee_no AS CHAR) LIKE ? OR " +
                        "title LIKE ? OR " +
                        "CAST(from_date AS CHAR) LIKE ? OR " +
                        "CAST(to_date AS CHAR) LIKE ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // Bind keyword with wildcards for partial matches across all fields
            String searchPattern = "%" + keyword + "%";
            ps.setString(1, searchPattern); // employee_no
            ps.setString(2, searchPattern); // title
            ps.setString(3, searchPattern); // from_date
            ps.setString(4, searchPattern); // to_date

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                empRoles.add(new EmpRole( // Instantiate EmpRole model
                        rs.getInt("employee_no"),
                        rs.getString("title"),
                        rs.getDate("from_date"),
                        rs.getDate("to_date")
                ));
            }

        } catch (SQLException e) {
            System.err.println("Search failed:");
            e.printStackTrace();
        }
    }

    //============================

    private boolean employeeExists(int empNo) {
        String sql = "SELECT employee_no FROM employee WHERE employee_no = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empNo);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void syncEmployeeJobTitle(int empNo, String newTitle) {
        String sql = "UPDATE employee SET job_title=? WHERE employee_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newTitle);
            ps.setInt(2, empNo);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

