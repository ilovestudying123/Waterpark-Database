package com.example.goolagoondb;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.Node;
import java.io.IOException;

public class MainMenuController {

    @FXML
    private Button btnRecords;

    @FXML
    private Button btnTransactions;

    @FXML
    private Button btnReports;

    // Open Records view
    @FXML
    private void openRecords(ActionEvent event) throws IOException {
        switchScene(event, "Records-View.fxml");
    }

    // Open Transactions view
    @FXML
    private void openTransactions(ActionEvent event) throws IOException {
        switchScene(event, "Transactions-View.fxml");
    }

    // Open Reports view
    @FXML
    private void openReports(ActionEvent event) throws IOException {
        switchScene(event, "Reports-View.fxml");
    }

    // Helper method to switch scenes and pass the primaryStage to each controller
    private void switchScene(ActionEvent event, String fxmlFile) throws IOException {
        // Load the FXML file for the target scene
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/goolagoondb/" + fxmlFile));

        // Load the scene
        Scene scene = new Scene(loader.load());

        // Get the stage (the current window)
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        // Retrieve the controller from the FXML loader
        Object controller = loader.getController();

        // Set the new scene and show it
        stage.setScene(scene);
        stage.show();
    }
}
