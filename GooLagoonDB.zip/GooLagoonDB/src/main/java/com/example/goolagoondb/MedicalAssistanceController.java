package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;

public class MedicalAssistanceController {

    @FXML private ComboBox<Integer> cmbEmpNum;
    @FXML private ComboBox<Integer> cmbRideNum;
    @FXML private ListView<Integer> lvMAInvolvedCustomerNum;
    @FXML private DatePicker dvDateofIncident;
    @FXML private TextField txtMAIncidentDesc;
    @FXML private TextField txtMAInjuriesDesc;
    @FXML private TextField txtMAReimbursementAmount;
    @FXML private Label lblOutput;

    private ObservableList<Integer> employeeNumbers = FXCollections.observableArrayList();
    private ObservableList<Integer> rideNumbers = FXCollections.observableArrayList();
    private ObservableList<Integer> customerNumbers = FXCollections.observableArrayList();

    // Database connection info
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        loadEmployees();
        loadRides();
        loadCustomers();
    }

    private void loadEmployees() {
        employeeNumbers.clear();
        String sql = "SELECT employee_no FROM employee WHERE is_active=1";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                employeeNumbers.add(rs.getInt("employee_no"));
            }
            cmbEmpNum.setItems(employeeNumbers);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadRides() {
        rideNumbers.clear();
        String sql = "SELECT ride_no FROM ride_attraction";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                rideNumbers.add(rs.getInt("ride_no"));
            }
            cmbRideNum.setItems(rideNumbers);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadCustomers() {
        customerNumbers.clear();
        String sql = "SELECT customer_no FROM customer";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                customerNumbers.add(rs.getInt("customer_no"));
            }
            lvMAInvolvedCustomerNum.setItems(customerNumbers);
            lvMAInvolvedCustomerNum.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void submitIncident(ActionEvent event) {
        if (dvDateofIncident.getValue() == null || cmbEmpNum.getValue() == null || cmbRideNum.getValue() == null) {
            lblOutput.setText("Please fill all required fields.");
            return;
        }

        LocalDate date = dvDateofIncident.getValue();
        String incidentDesc = txtMAIncidentDesc.getText();
        String injuriesDesc = txtMAInjuriesDesc.getText();
        boolean reimbursementStatus = false; // always unpaid
        double reimbursementAmount = 0.0;

        try {
            reimbursementAmount = Double.parseDouble(txtMAReimbursementAmount.getText());
        } catch (NumberFormatException e) {
            // keep as 0 if invalid
        }

        int empNo = cmbEmpNum.getValue();
        int rideNo = cmbRideNum.getValue();
        ObservableList<Integer> selectedCustomers = lvMAInvolvedCustomerNum.getSelectionModel().getSelectedItems();

        if (selectedCustomers.isEmpty()) {
            lblOutput.setText("Select at least one customer.");
            return;
        }

        String insertIncidentSQL = "INSERT INTO incident (date_of_incident, incident_desc, injuries_desc, reimbursement_status, employee_no, ride_no) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(insertIncidentSQL, Statement.RETURN_GENERATED_KEYS)) {

            ps.setDate(1, Date.valueOf(date));
            ps.setString(2, incidentDesc);
            ps.setString(3, injuriesDesc);
            ps.setBoolean(4, reimbursementStatus);
            ps.setInt(5, empNo);
            ps.setInt(6, rideNo);

            ps.executeUpdate();

            // Get the generated incident_no
            ResultSet rs = ps.getGeneratedKeys();
            int incidentNo = -1;
            if (rs.next()) {
                incidentNo = rs.getInt(1);
            }

            // Insert into customer_incident for each selected customer
            String insertCI = "INSERT INTO customer_incident (incident_no, customer_no) VALUES (?, ?)";
            try (PreparedStatement psCI = conn.prepareStatement(insertCI)) {
                for (int custNo : selectedCustomers) {
                    psCI.setInt(1, incidentNo);
                    psCI.setInt(2, custNo);
                    psCI.executeUpdate();
                }
            }

            lblOutput.setText("Incident successfully recorded.");
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
            lblOutput.setText("Error saving incident.");
        }
    }

    @FXML
    private void goBack(ActionEvent event) {
        try {
            switchScene(event, "Main-Menu.fxml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Helper method to switch scenes
    private void switchScene(ActionEvent event, String fxmlFile) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/goolagoondb/" + fxmlFile));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    private void clearFields() {
        dvDateofIncident.setValue(null);
        txtMAIncidentDesc.clear();
        txtMAInjuriesDesc.clear();
        txtMAReimbursementAmount.clear();
        cmbEmpNum.getSelectionModel().clearSelection();
        cmbRideNum.getSelectionModel().clearSelection();
        lvMAInvolvedCustomerNum.getSelectionModel().clearSelection();
    }
}
