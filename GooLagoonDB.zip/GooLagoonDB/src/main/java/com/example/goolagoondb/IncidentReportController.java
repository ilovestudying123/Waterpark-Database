package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class IncidentReportController {

    @FXML private TableView<IncidentReport> incidentReportTable;

    @FXML private TableColumn<IncidentReport, String> IdateColumn;
    @FXML private TableColumn<IncidentReport, String> IrideColumn;
    @FXML private TableColumn<IncidentReport, String> IlastnameColumn;
    @FXML private TableColumn<IncidentReport, String> IfirstnameColumn;
    @FXML private TableColumn<IncidentReport, String> IempColumn;
    @FXML private TableColumn<IncidentReport, String> IincidentDescColumn;
    @FXML private TableColumn<IncidentReport, String> IinjuriesDescColumn;
    @FXML private TableColumn<IncidentReport, String> IstatusColumn;

    private ObservableList<IncidentReport> reportList = FXCollections.observableArrayList();

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadReportData();
    }

    private void setupColumns() {
        IdateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        IrideColumn.setCellValueFactory(new PropertyValueFactory<>("rideName"));
        IlastnameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        IfirstnameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        IempColumn.setCellValueFactory(new PropertyValueFactory<>("employeeName"));
        IincidentDescColumn.setCellValueFactory(new PropertyValueFactory<>("incidentDesc"));
        IinjuriesDescColumn.setCellValueFactory(new PropertyValueFactory<>("injuriesDesc"));
        IstatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        incidentReportTable.setItems(reportList);
    }

    private void loadReportData() {
        reportList.clear();

        String sql =
                "SELECT " +
                        "    i.date_of_incident, " +
                        "    r.name AS ride_name, " +
                        "    c.last_name, c.first_name, " +
                        "    CONCAT(e.first_name, ' ', e.last_name) AS employee_name, " +
                        "    i.incident_desc, i.injuries_desc, " +
                        "    CASE WHEN i.reimbursement_status = 1 THEN 'Paid' ELSE 'Unpaid' END AS status " +
                        "FROM customer_incident ci " +
                        "JOIN customer c ON ci.customer_no = c.customer_no " +
                        "JOIN incident i ON ci.incident_no = i.incident_no " +
                        "JOIN ride_attraction r ON i.ride_no = r.ride_no " +
                        "JOIN employee e ON i.employee_no = e.employee_no " +
                        "ORDER BY i.date_of_incident DESC";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                reportList.add(new IncidentReport(
                        rs.getString("date_of_incident"),
                        rs.getString("ride_name"),
                        rs.getString("last_name"),
                        rs.getString("first_name"),
                        rs.getString("employee_name"),
                        rs.getString("incident_desc"),
                        rs.getString("injuries_desc"),
                        rs.getString("status")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}