package com.example.goolagoondb;

public class IncidentReport {

    private String date;
    private String rideName;
    private String lastName;
    private String firstName;
    private String employeeName;
    private String incidentDesc;
    private String injuriesDesc;
    private String status;

    public IncidentReport(String date, String rideName, String lastName, String firstName,
                          String employeeName, String incidentDesc, String injuriesDesc, String status) {
        this.date = date;
        this.rideName = rideName;
        this.lastName = lastName;
        this.firstName = firstName;
        this.employeeName = employeeName;
        this.incidentDesc = incidentDesc;
        this.injuriesDesc = injuriesDesc;
        this.status = status;
    }

    public String getDate() { return date; }
    public String getRideName() { return rideName; }
    public String getLastName() { return lastName; }
    public String getFirstName() { return firstName; }
    public String getEmployeeName() { return employeeName; }
    public String getIncidentDesc() { return incidentDesc; }
    public String getInjuriesDesc() { return injuriesDesc; }
    public String getStatus() { return status; }
}
