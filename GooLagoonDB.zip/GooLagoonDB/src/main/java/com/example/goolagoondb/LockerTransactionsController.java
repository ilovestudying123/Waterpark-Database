package com.example.goolagoondb;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;
import java.io.IOException;

public class LockerTransactionsController {

    // FXML fields
    @FXML
    private TextField txtOTCustomerNumber;
    @FXML
    private TextField txtOTFirstName;
    @FXML
    private TextField txtOTLastName;
    @FXML
    private TextField txtOTPhone;
    @FXML
    private TextField txtOTEmail;
    @FXML
    private TextField txtOTAge;
    @FXML
    private CheckBox chkOTPWD;
    @FXML
    private Label lblOutput;
    @FXML
    private Button btnOTBack;
    @FXML
    private Button btnOTProceed;

    // Called when "Back" button is clicked
    @FXML
    private void goBack(ActionEvent event) {
        try {
            switchScene(event, "Transactions-View.fxml"); // Go back to transactions menu
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Called when "Proceed" button is clicked
    @FXML
    private void rentLocker(ActionEvent event) {
        // TODO: Add locker transaction logic here
        lblOutput.setText("Proceed clicked! Implement locker transaction.");
    }

    // Helper method to switch scenes
    private void switchScene(ActionEvent event, String fxmlFile) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/goolagoondb/" + fxmlFile));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
