package com.example.goolagoondb;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class DemographicReport {
    private final SimpleStringProperty ticketType;
    private final SimpleIntegerProperty total;

    // No-arg constructor for FXML
    public DemographicReport() {
        this.ticketType = new SimpleStringProperty("");
        this.total = new SimpleIntegerProperty(0);
    }

    // Constructor for TableView
    public DemographicReport(String ticketType, int total) {
        this.ticketType = new SimpleStringProperty(ticketType);
        this.total = new SimpleIntegerProperty(total);
    }

    public String getTicketType() {
        return ticketType.get();
    }

    public void setTicketType(String ticketType) {
        this.ticketType.set(ticketType);
    }

    public int getTotal() {
        return total.get();
    }

    public void setTotal(int total) {
        this.total.set(total);
    }

    public SimpleStringProperty ticketTypeProperty() {
        return ticketType;
    }

    public SimpleIntegerProperty totalProperty() {
        return total;
    }
}
