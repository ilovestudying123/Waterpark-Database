package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;

public class ViolationReportController {

    @FXML private TableView<ViolationReport> violationsReportTable;
    @FXML private TableColumn<ViolationReport, String> RrideNameColumn;
    @FXML private TableColumn<ViolationReport, Double> RphLevelColumn;
    @FXML private TableColumn<ViolationReport, Double> RchlorineLevelColumn;
    @FXML private TableColumn<ViolationReport, Double> RwaterTempColumn;
    @FXML private TableColumn<ViolationReport, Integer> RtotalViolations;

    private ObservableList<ViolationReport> violationReports = FXCollections.observableArrayList();

    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupTableColumns();
        loadViolationData();
    }

    private void setupTableColumns() {
        RrideNameColumn.setCellValueFactory(new PropertyValueFactory<>("rideName"));
        RphLevelColumn.setCellValueFactory(new PropertyValueFactory<>("avgPhLevel"));
        RchlorineLevelColumn.setCellValueFactory(new PropertyValueFactory<>("avgChlorineLevel"));
        RwaterTempColumn.setCellValueFactory(new PropertyValueFactory<>("avgWaterTemp"));
        RtotalViolations.setCellValueFactory(new PropertyValueFactory<>("totalViolations"));

        violationsReportTable.setItems(violationReports);
    }

    private void loadViolationData() {
        String sql = "SELECT r.name AS rideName, " +
                "AVG(q.ph_level) AS avgPh, " +
                "AVG(q.chlorine_level) AS avgChlorine, " +
                "AVG(q.water_temp) AS avgTemp, " +
                "SUM(q.violation_count) AS totalViolations " +
                "FROM ride_attraction r " +
                "LEFT JOIN quality_inspection q ON r.ride_no = q.ride_no " +
                "GROUP BY r.name";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            violationReports.clear();

            while (rs.next()) {
                violationReports.add(new ViolationReport(
                        rs.getString("rideName"),
                        rs.getDouble("avgPh"),
                        rs.getDouble("avgChlorine"),
                        rs.getDouble("avgTemp"),
                        rs.getInt("totalViolations")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}