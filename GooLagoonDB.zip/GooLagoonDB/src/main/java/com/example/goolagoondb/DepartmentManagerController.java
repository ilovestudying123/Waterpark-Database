package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.sql.Date;

public class DepartmentManagerController {

    @FXML private TableView<DepartmentManager> DepartmentManagerTable;
    @FXML private TableColumn<DepartmentManager, Integer> dmDepartmentNumberColumn;
    @FXML private TableColumn<DepartmentManager, Integer> dmEmployeeNumberColumn;
    @FXML private TableColumn<DepartmentManager, Date> dmFromDate;
    @FXML private TableColumn<DepartmentManager, Date> dmToDate;


    // Textfields
    @FXML private TextField txtDMRDeptNumber;
    @FXML private TextField txtDMREmpNumber;
    @FXML private TextField txtDMRFromDate;
    @FXML private TextField txtDMRToDate;

    @FXML private TextField txtDMRSearch;

    private ObservableList<DepartmentManager> deptMan = FXCollections.observableArrayList();

    // DB SETUP
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadDeptManagerData();

        DepartmentManagerTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        selectDeptManager();
                    }
                }
        );
    }

    private void setupColumns() {
        dmDepartmentNumberColumn.setCellValueFactory(new PropertyValueFactory<>("department_no"));
        dmEmployeeNumberColumn.setCellValueFactory(new PropertyValueFactory<>("employee_no"));
        dmFromDate.setCellValueFactory(new PropertyValueFactory<>("from_date"));
        dmToDate.setCellValueFactory(new PropertyValueFactory<>("to_date"));

        DepartmentManagerTable.setItems(deptMan);
    }

    // Renamed method and updated logic to load 'department_manager' data
    private void loadDeptManagerData() {
        deptMan.clear();

        // SQL query now selects from the department_manager table
        String sql = "SELECT department_no, employee_no, from_date, to_date FROM department_manager";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                deptMan.add(new DepartmentManager(
                        rs.getInt("department_no"),
                        rs.getInt("employee_no"),
                        rs.getDate("from_date"),
                        rs.getDate("to_date") // to_date can be null
                ));
            }

        } catch (SQLException e) {
            System.err.println("Failed to load Department Manager data:");
            e.printStackTrace();
        }
    }

    // ================================
    // ADD DEPARTMENT MANAGER ASSIGNMENT
    // ================================
    @FXML
    private void addDeptManager() {
        String sql = "INSERT INTO department_manager (department_no, employee_no, from_date, to_date) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // 1. department_no (INT)
            ps.setInt(1, Integer.parseInt(txtDMRDeptNumber.getText()));
            // 2. employee_no (INT)
            ps.setInt(2, Integer.parseInt(txtDMREmpNumber.getText()));
            // 3. from_date (DATE)
            ps.setDate(3, Date.valueOf(txtDMRFromDate.getText()));

            // 4. to_date (DATE) - Handle nullable field
            String toDateText = txtDMRToDate.getText();
            if (toDateText == null || toDateText.trim().isEmpty()) {
                ps.setNull(4, Types.DATE);
            } else {
                ps.setDate(4, Date.valueOf(toDateText));
            }

            ps.executeUpdate();

            loadDeptManagerData();
            clearFields();

        } catch (SQLException e) {
            System.err.println("Failed to add Department Manager assignment:");
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            System.err.println("Input format error: Check Department #, Employee #, and Date formats (YYYY-MM-DD).");
        }
    }

    // ================================
    // UPDATE DEPARTMENT MANAGER ASSIGNMENT
    // We assume update means setting or changing the to_date for an existing assignment (PK: dept#, emp#, from_date)
    // ================================
    @FXML
    private void updateDeptManager() {
        // SQL updates the to_date for a specific assignment identified by its composite primary key
        String sql = "UPDATE department_manager SET to_date=? WHERE department_no=? AND employee_no=? AND from_date=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // 1. to_date (SET clause) - Handle nullable field
            String toDateText = txtDMRToDate.getText();
            if (toDateText == null || toDateText.trim().isEmpty()) {
                ps.setNull(1, Types.DATE);
            } else {
                ps.setDate(1, Date.valueOf(toDateText));
            }

            // WHERE clause parameters (Composite PK)
            // 2. department_no
            ps.setInt(2, Integer.parseInt(txtDMRDeptNumber.getText()));
            // 3. employee_no
            ps.setInt(3, Integer.parseInt(txtDMREmpNumber.getText()));
            // 4. from_date
            ps.setDate(4, Date.valueOf(txtDMRFromDate.getText()));

            ps.executeUpdate();

            loadDeptManagerData();
            clearFields();

        } catch (SQLException e) {
            System.err.println("Failed to update Department Manager assignment:");
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            System.err.println("Input format error: Check Department #, Employee #, and Date formats (YYYY-MM-DD).");
        }
    }

    // ================================
    // DELETE DEPARTMENT MANAGER ASSIGNMENT
    // Deletes an assignment identified by its composite primary key
    // ================================
    @FXML
    private void deleteDeptManager() {
        String sql = "DELETE FROM department_manager WHERE department_no=? AND employee_no=? AND from_date=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // Composite Primary Key parameters
            ps.setInt(1, Integer.parseInt(txtDMRDeptNumber.getText()));
            ps.setInt(2, Integer.parseInt(txtDMREmpNumber.getText()));
            ps.setDate(3, Date.valueOf(txtDMRFromDate.getText()));

            ps.executeUpdate();

            loadDeptManagerData();
            clearFields();

        } catch (SQLException e) {
            System.err.println("Failed to delete Department Manager assignment:");
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            System.err.println("Input format error: Please select a valid assignment to delete.");
        }
    }

    // ================================
    // CLEAR FIELDS
    // ================================
    @FXML
    private void clearFields() {
        txtDMRDeptNumber.clear();
        txtDMREmpNumber.clear();
        txtDMRFromDate.clear();
        txtDMRToDate.clear();
        txtDMRSearch.clear(); // Clear search field as well
    }

    // ================================
    // SELECT DEPARTMENT MANAGER FROM TABLE
    // ================================
    private void selectDeptManager() {
        DepartmentManager dm = DepartmentManagerTable.getSelectionModel().getSelectedItem();
        if (dm == null) return;

        txtDMRDeptNumber.setText(String.valueOf(dm.getDepartment_no()));
        txtDMREmpNumber.setText(String.valueOf(dm.getEmployee_no()));
        txtDMRFromDate.setText(dm.getFrom_date().toString());

        // Handle nullable to_date
        if (dm.getTo_date() != null) {
            txtDMRToDate.setText(dm.getTo_date().toString());
        } else {
            txtDMRToDate.clear();
        }
    }

    // ================================
    // SEARCH DEPARTMENT MANAGER ASSIGNMENTS
    // ================================
    @FXML
    private void handleSearch() {
        String keyword = txtDMRSearch.getText().trim();

        if (keyword.isEmpty()) {
            loadDeptManagerData();
            return;
        }

        deptMan.clear();

        // Search for keyword across department #, employee #, and dates
        String sql =
                "SELECT * FROM department_manager WHERE " +
                        "CAST(department_no AS CHAR) LIKE ? OR " +
                        "CAST(employee_no AS CHAR) LIKE ? OR " +
                        "CAST(from_date AS CHAR) LIKE ? OR " +
                        "CAST(to_date AS CHAR) LIKE ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // Bind keyword with wildcards for partial matches across all fields
            String searchPattern = "%" + keyword + "%";
            ps.setString(1, searchPattern); // department_no
            ps.setString(2, searchPattern); // employee_no
            ps.setString(3, searchPattern); // from_date
            ps.setString(4, searchPattern); // to_date

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                deptMan.add(new DepartmentManager(
                        rs.getInt("department_no"),
                        rs.getInt("employee_no"),
                        rs.getDate("from_date"),
                        rs.getDate("to_date")
                ));
            }

        } catch (SQLException e) {
            System.err.println("Search failed:");
            e.printStackTrace();
        }
    }
}
