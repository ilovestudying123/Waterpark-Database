package com.example.goolagoondb;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class TicketTransactionsController {

    @FXML
    private TextField txtOTCustomerNumber, txtOTFirstName, txtOTLastName, txtOTPhone, txtOTEmail, txtOTAge;

    @FXML
    private CheckBox chkOTPWD;

    @FXML
    private Button btnOTProceed, btnOTBack;

    @FXML
    private Label lblOutput;

    @FXML
    private void initialize() {
        // Back button action
        btnOTBack.setOnAction(this::goBack);
    }

    @FXML
    private void orderTicket(ActionEvent event) {
        // Example validation and output
        String firstName = txtOTFirstName.getText().trim();
        String lastName = txtOTLastName.getText().trim();
        String customerNo = txtOTCustomerNumber.getText().trim();

        if (customerNo.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
            lblOutput.setText("Customer No., First Name, and Last Name are required!");
            return;
        }

        // Simulate ticket ordering
        boolean isPWD = chkOTPWD.isSelected();
        lblOutput.setText("Ticket ordered for " + firstName + " " + lastName + (isPWD ? " (PWD)" : ""));

        // TODO: add DB insertion here
    }

    @FXML
    private void goBack(ActionEvent event) {
        try {
            switchScene(event, "Transactions-View.fxml"); // Go back to transactions menu
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void switchScene(ActionEvent event, String fxmlFile) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/goolagoondb/" + fxmlFile));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
