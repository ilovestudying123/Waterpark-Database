package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.math.BigDecimal;
import java.sql.Date;

public class QualityInspectionController {

    @FXML private TableView<QualityInspection> QualityInspectionTable;
    @FXML private TableColumn<QualityInspection, Integer> rideNumberColumn1;
    @FXML private TableColumn<QualityInspection, Date> qualityInspectionDateTaken;
    @FXML private TableColumn<QualityInspection, BigDecimal> qualityInspectionPHLevel;
    @FXML private TableColumn<QualityInspection, BigDecimal> qualityInspectionChlorineLevel;
    @FXML private TableColumn<QualityInspection, BigDecimal> qualityInspectionWaterTemperature;
    @FXML private TableColumn<QualityInspection, Integer> qualityInspectionViolationCount;
    @FXML private TableColumn<QualityInspection, String> qualityInspectionViolationDescription;

    // Textfields
    @FXML private TextField txtQIRRideNumber;
    @FXML private TextField txtQIRDateTaken;
    @FXML private TextField txtPHLevel;
    @FXML private TextField txtChlorineLevel;
    @FXML private TextField txtWaterTemperature;
    @FXML private TextField txtViolationCount;
    @FXML private TextField txtViolationDescription;

    @FXML private TextField txtQIRSearch;

    private ObservableList<QualityInspection> inspection = FXCollections.observableArrayList();

    // DB SETUP
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadInspectionData();

        QualityInspectionTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        selectInspection();
                    }
                }
        );
    }

    private void setupColumns() {
        rideNumberColumn1.setCellValueFactory(new PropertyValueFactory<>("ride_no"));
        qualityInspectionDateTaken.setCellValueFactory(new PropertyValueFactory<>("date_of_inspection"));
        qualityInspectionPHLevel.setCellValueFactory(new PropertyValueFactory<>("ph_level"));
        qualityInspectionChlorineLevel.setCellValueFactory(new PropertyValueFactory<>("chlorine_level"));
        qualityInspectionWaterTemperature.setCellValueFactory(new PropertyValueFactory<>("water_temp"));
        qualityInspectionViolationCount.setCellValueFactory(new PropertyValueFactory<>("violation_count"));
        qualityInspectionViolationDescription.setCellValueFactory(new PropertyValueFactory<>("violation_desc"));

        QualityInspectionTable.setItems(inspection);
    }

    private void loadInspectionData() {
        inspection.clear();

        String sql = "SELECT * FROM quality_inspection";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                inspection.add(new QualityInspection(
                        rs.getDate("date_of_inspection"),
                        rs.getInt("ride_no"),
                        rs.getBigDecimal("ph_level"),
                        rs.getBigDecimal("chlorine_level"),
                        rs.getBigDecimal("water_temp"),
                        rs.getInt("violation_count"),
                        rs.getString("violation_desc")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================================
    // ADD QUALITY INSPECTION
    // ================================
    @FXML
    private void addQualityInspection() {
        // Input validation
        if (txtQIRRideNumber.getText().isEmpty() || txtQIRDateTaken.getText().isEmpty() ||
                txtPHLevel.getText().isEmpty() || txtChlorineLevel.getText().isEmpty() ||
                txtWaterTemperature.getText().isEmpty() || txtViolationCount.getText().isEmpty() ||
                txtViolationDescription.getText().isEmpty()) {

            System.out.println("Please fill in all fields.");
            return;
        }

        String sql = "INSERT INTO quality_inspection " +
                "(ride_no, date_of_inspection, ph_level, chlorine_level, water_temp, violation_count, violation_desc) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // Parse and set values
            int rideNo = Integer.parseInt(txtQIRRideNumber.getText());
            Date dateOfInspection = Date.valueOf(txtQIRDateTaken.getText());
            BigDecimal phLevel = new BigDecimal(txtPHLevel.getText());
            BigDecimal chlorineLevel = new BigDecimal(txtChlorineLevel.getText());
            BigDecimal waterTemp = new BigDecimal(txtWaterTemperature.getText());
            int violationCount = Integer.parseInt(txtViolationCount.getText());
            String violationDesc = txtViolationDescription.getText();

            // Optional: check ride_no exists
            String rideCheck = "SELECT COUNT(*) FROM ride_attraction WHERE ride_no=?";
            try (PreparedStatement checkStmt = conn.prepareStatement(rideCheck)) {
                checkStmt.setInt(1, rideNo);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) == 0) {
                    System.out.println("Ride number does not exist.");
                    return;
                }
            }

            ps.setInt(1, rideNo);
            ps.setDate(2, dateOfInspection);
            ps.setBigDecimal(3, phLevel);
            ps.setBigDecimal(4, chlorineLevel);
            ps.setBigDecimal(5, waterTemp);
            ps.setInt(6, violationCount);
            ps.setString(7, violationDesc);

            ps.executeUpdate();
            loadInspectionData();
            clearFields();

            System.out.println("Quality inspection added successfully.");

        } catch (NumberFormatException e) {
            System.out.println("Invalid number format in one of the fields.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database error:");
            e.printStackTrace();
        }
    }

    // ================================
    // UPDATE QUALITY INSPECTION
    // ================================
    @FXML
    private void updateQualityInspection() {
        String sql = "UPDATE quality_inspection SET date_of_inspection=?, ph_level=?, chlorine_level=?, water_temp=?, violation_count=?, violation_desc=? " +
                "WHERE ride_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(txtQIRDateTaken.getText()));
            ps.setBigDecimal(2, new BigDecimal(txtPHLevel.getText()));
            ps.setBigDecimal(3, new BigDecimal(txtChlorineLevel.getText()));
            ps.setBigDecimal(4, new BigDecimal(txtWaterTemperature.getText()));
            ps.setInt(5, Integer.parseInt(txtViolationCount.getText()));
            ps.setString(6, txtViolationDescription.getText());
            ps.setInt(7, Integer.parseInt(txtQIRRideNumber.getText()));

            ps.executeUpdate();
            loadInspectionData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================================
    // DELETE QUALITY INSPECTION
    // ================================
    @FXML
    private void deleteQualityInspection() {

        // Check if the Date field is populated (since it holds the PK)
        if (txtQIRDateTaken.getText().isEmpty()) {
            System.out.println("Please select a record by its date to delete.");
            return;
        }

        // The SQL only needs the Primary Key: date_of_inspection
        String sql = "DELETE FROM quality_inspection WHERE date_of_inspection=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // Set the date_of_inspection parameter (the unique key)
            ps.setDate(1, Date.valueOf(txtQIRDateTaken.getText()));

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Successfully deleted " + rowsAffected + " inspection record(s).");
                loadInspectionData();
                clearFields();
            } else {
                System.out.println("No record found to delete.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid date format in the date field.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database error during deletion.");
            e.printStackTrace();
        }
    }

    // ================================
    // CLEAR FIELDS
    // ================================
    @FXML
    private void clearFields() {
        txtQIRRideNumber.clear();
        txtQIRDateTaken.clear();
        txtPHLevel.clear();
        txtChlorineLevel.clear();
        txtWaterTemperature.clear();
        txtViolationCount.clear();
        txtViolationDescription.clear();
    }

    // ================================
    // SELECT INSPECTION FROM TABLE
    // ================================
    private void selectInspection() {
        QualityInspection qi = QualityInspectionTable.getSelectionModel().getSelectedItem();
        if (qi == null) return;

        txtQIRRideNumber.setText(String.valueOf(qi.getRide_no()));
        txtQIRDateTaken.setText(qi.getDate_of_inspection().toString());
        txtPHLevel.setText(qi.getPh_level().toString());
        txtChlorineLevel.setText(qi.getChlorine_level().toString());
        txtWaterTemperature.setText(qi.getWater_temp().toString());
        txtViolationCount.setText(String.valueOf(qi.getViolation_count()));
        txtViolationDescription.setText(qi.getViolation_desc());
    }

    // ================================
    // SEARCH INSPECTION
    // ================================
    @FXML
    private void handleSearch() {
        String keyword = txtQIRSearch.getText().trim();

        if (keyword.isEmpty()) {
            loadInspectionData();  // reload all inspections
            return;
        }

        inspection.clear();

        String sql =
                "SELECT * FROM quality_inspection WHERE " +
                        "CAST(ride_no AS CHAR) = ? OR " +
                        "CAST(date_of_inspection AS CHAR) LIKE ? OR " +
                        "CAST(ph_level AS CHAR) LIKE ? OR " +
                        "CAST(chlorine_level AS CHAR) LIKE ? OR " +
                        "CAST(water_temp AS CHAR) LIKE ? OR " +
                        "CAST(violation_count AS CHAR) = ? OR " +
                        "violation_desc LIKE ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, keyword);
            ps.setString(2, "%" + keyword + "%");
            ps.setString(3, "%" + keyword + "%");
            ps.setString(4, "%" + keyword + "%");
            ps.setString(5, "%" + keyword + "%");
            ps.setString(6, keyword);
            ps.setString(7, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                inspection.add(new QualityInspection(
                        rs.getDate("date_of_inspection"),
                        rs.getInt("ride_no"),
                        rs.getBigDecimal("ph_level"),
                        rs.getBigDecimal("chlorine_level"),
                        rs.getBigDecimal("water_temp"),
                        rs.getInt("violation_count"),
                        rs.getString("violation_desc")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}