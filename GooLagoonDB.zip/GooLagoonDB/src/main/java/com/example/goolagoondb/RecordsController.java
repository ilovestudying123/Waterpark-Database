package com.example.goolagoondb;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.Region;

import java.io.IOException;

public class RecordsController  {

    @FXML
    private TabPane tabPane;

    @FXML
    private void initialize() {
        System.out.println("Records view loaded!");

        // Load each tab programmatically
        loadTab("Customer Records", "Customer-Records.fxml");
        loadTab("Customer Incident Records", "Customer-Incident-Records.fxml");
        loadTab("Incident Records", "Incident-Records.fxml");
        loadTab("Locker Records", "Locker-Records.fxml");
        loadTab("Ticket Records", "Ticket-Records.fxml");
        loadTab("Employee Records", "Employee-Records.fxml");
        loadTab("Employee Role Records", "Employee-Role-Records.fxml");
        loadTab("Ride Attraction Records", "Ride-Attraction-Records.fxml");
        loadTab("Quality Inspection Records", "Quality-Inspection-Records.fxml");
        loadTab("Department Records", "Department-Records.fxml");
        loadTab("Department Manager Records", "Department-Manager-Records.fxml");
    }

    private void loadTab(String title, String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/goolagoondb/" + fxmlFile)
            );
            Region content = loader.load();

            Tab tab = new Tab(title);
            tab.setContent(content);
            tab.setClosable(false); // keep same behavior as fx:include
            tabPane.getTabs().add(tab);

        } catch (IOException e) {
            System.err.println("Failed to load tab: " + title + " (" + fxmlFile + ")");
            e.printStackTrace();
        }
    }
}
