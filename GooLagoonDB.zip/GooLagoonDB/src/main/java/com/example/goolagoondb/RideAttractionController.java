package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class RideAttractionController {

    @FXML private TableView<RideAttraction> RideAttractionTable;
    @FXML private TableColumn<RideAttraction, Integer> rideNumberColumn;
    @FXML private TableColumn<RideAttraction, String> rideNameColumn;
    @FXML private TableColumn<RideAttraction, String> rideDescriptionColumn;
    @FXML private TableColumn<RideAttraction, Date> rideDateOfInspectionColumn;
    @FXML private TableColumn<RideAttraction, Integer> rideCapacityColumn;
    @FXML private TableColumn<RideAttraction, Integer> rideMinHeightColumn;
    @FXML private TableColumn<RideAttraction, String> rideTicketRequirementColumn;
    @FXML private TableColumn<RideAttraction, String> rideStatusColumn;

    // Textfields
    @FXML private TextField txtRARRideNumber;
    @FXML private TextField txtRARName;
    @FXML private TextField txtRARDateOfInspection;
    @FXML private TextField txtRARDescription;
    @FXML private TextField txtRARCapacity;
    @FXML private TextField txtRARMinimumHeight;
    @FXML private TextField txtRARTicketRequirement;

    // Status for ride (Active/Inactive)
    @FXML private CheckBox chkRARActive;
    @FXML private TextField txtRARSearch;

    private ObservableList<RideAttraction> rides = FXCollections.observableArrayList();

    // DB SETUP
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadRideData();

        RideAttractionTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        selectRide();
                    }
                }
        );
    }

    private void setupColumns() {
        rideNumberColumn.setCellValueFactory(new PropertyValueFactory<>("ride_no"));
        rideNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        rideDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        rideDateOfInspectionColumn.setCellValueFactory(new PropertyValueFactory<>("date_of_inspection"));
        rideCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("ride_capacity"));
        rideMinHeightColumn.setCellValueFactory(new PropertyValueFactory<>("height_requirement"));
        rideTicketRequirementColumn.setCellValueFactory(new PropertyValueFactory<>("ticket_requirement"));
        rideStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        RideAttractionTable.setItems(rides);
    }

    private void loadRideData() {
        rides.clear();

        String sql = "SELECT ride_no, name, description, date_of_inspection, ride_capacity, height_requirement, ticket_requirement, status FROM ride_attraction";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                rides.add(new RideAttraction(
                        rs.getInt("ride_no"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDate("date_of_inspection"),
                        rs.getInt("ride_capacity"),
                        rs.getInt("height_requirement"),
                        rs.getString("ticket_requirement"),
                        rs.getString("status")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================================
    // ADD RIDE
    // ================================
    @FXML
    private void addRideAttraction() {
        String sql = "INSERT INTO ride_attraction (ride_no, name, description, date_of_inspection, ride_capacity, height_requirement, ticket_requirement, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtRARRideNumber.getText()));
            ps.setString(2, txtRARName.getText());
            ps.setString(3, txtRARDescription.getText());

            // Convert Date
            String dateStr = txtRARDateOfInspection.getText();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate localDate = LocalDate.parse(dateStr, formatter);
            ps.setDate(4, Date.valueOf(localDate));

            ps.setInt(5, Integer.parseInt(txtRARCapacity.getText()));
            ps.setInt(6, Integer.parseInt(txtRARMinimumHeight.getText()));
            ps.setString(7, txtRARTicketRequirement.getText());

            // Active/Inactive
            ps.setString(8, chkRARActive.isSelected() ? "Operational" : "Down");

            ps.executeUpdate();

            loadRideData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================================
    // UPDATE RIDE
    // ================================
    @FXML
    private void updateRideAttraction() {
        String sql = "UPDATE ride_attraction SET ride_no=?, name=?, description=?, date_of_inspection=?, ride_capacity=?, height_requirement=?, ticket_requirement=?, status=? WHERE ride_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtRARRideNumber.getText()));
            ps.setString(2, txtRARName.getText());
            ps.setString(3, txtRARDescription.getText());
            String dateStr = txtRARDateOfInspection.getText();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate localDate = LocalDate.parse(dateStr, formatter);
            ps.setDate(4, Date.valueOf(localDate));
            ps.setInt(5, Integer.parseInt(txtRARCapacity.getText()));
            ps.setInt(6, Integer.parseInt(txtRARMinimumHeight.getText()));
            ps.setString(7, txtRARTicketRequirement.getText());
            ps.setString(8, chkRARActive.isSelected() ? "Operational" : "Down");
            ps.setInt(9, Integer.parseInt(txtRARRideNumber.getText()));

            ps.executeUpdate();

            loadRideData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================================
    // DELETE RIDE
    // ================================
    @FXML
    private void deleteRideAttraction() {
        String sql = "DELETE FROM ride_attraction WHERE ride_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtRARRideNumber.getText()));
            ps.executeUpdate();

            loadRideData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================================
    // CLEAR FIELDS
    // ================================
    @FXML
    private void clearFields() {
        txtRARRideNumber.clear();
        txtRARName.clear();
        txtRARDescription.clear();
        txtRARDateOfInspection.clear();
        txtRARCapacity.clear();
        txtRARMinimumHeight.clear();
        txtRARTicketRequirement.clear();
        chkRARActive.setSelected(false);
    }

    // ================================
    // SELECT RIDE FROM TABLE
    // ================================
    private void selectRide() {
        RideAttraction r = RideAttractionTable.getSelectionModel().getSelectedItem();
        if (r == null) return;

        txtRARRideNumber.setText(String.valueOf(r.getRide_no()));
        txtRARName.setText(r.getName());
        txtRARDescription.setText(r.getDescription());
        txtRARDateOfInspection.setText(r.getDate_of_inspection().toString());
        txtRARCapacity.setText(String.valueOf(r.getRide_capacity()));
        txtRARMinimumHeight.setText(String.valueOf(r.getHeight_requirement()));
        txtRARTicketRequirement.setText(r.getTicket_requirement());
        chkRARActive.setSelected(r.getStatus().equalsIgnoreCase("Operational"));
    }

    @FXML
    private void handleSearch() {
        String keyword = txtRARSearch.getText().trim(); // <<< Make sure this TextField exists in FXML

        if (keyword.isEmpty()) {
            loadRideData(); // reload all rides
            return;
        }

        rides.clear();

        String sql =
                "SELECT * FROM ride_attraction WHERE " +
                        "CAST(ride_no AS CHAR) = ? OR " +
                        "name LIKE ? OR " +
                        "description LIKE ? OR " +
                        "CAST(date_of_inspection AS CHAR) = ? OR " +
                        "CAST(ride_capacity AS CHAR) = ? OR " +
                        "CAST(height_requirement AS CHAR) = ? OR " +
                        "ticket_requirement LIKE ? OR " +
                        "status = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // exact or partial matches
            ps.setString(1, keyword);
            ps.setString(2, "%" + keyword + "%");
            ps.setString(3, "%" + keyword + "%");
            ps.setString(4, keyword);
            ps.setString(5, keyword);
            ps.setString(6, keyword);
            ps.setString(7, "%" + keyword + "%");
            ps.setString(8, keyword);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                rides.add(new RideAttraction(
                        rs.getInt("ride_no"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDate("date_of_inspection"),
                        rs.getInt("ride_capacity"),
                        rs.getInt("height_requirement"),
                        rs.getString("ticket_requirement"),
                        rs.getString("status")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}