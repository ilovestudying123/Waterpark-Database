package com.example.goolagoondb;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class ViolationReport {

    private final SimpleStringProperty rideName;
    private final SimpleDoubleProperty avgPhLevel;
    private final SimpleDoubleProperty avgChlorineLevel;
    private final SimpleDoubleProperty avgWaterTemp;
    private final SimpleIntegerProperty totalViolations;

    public ViolationReport(String rideName, double avgPhLevel, double avgChlorineLevel, double avgWaterTemp, int totalViolations) {
        this.rideName = new SimpleStringProperty(rideName);
        this.avgPhLevel = new SimpleDoubleProperty(avgPhLevel);
        this.avgChlorineLevel = new SimpleDoubleProperty(avgChlorineLevel);
        this.avgWaterTemp = new SimpleDoubleProperty(avgWaterTemp);
        this.totalViolations = new SimpleIntegerProperty(totalViolations);
    }

    // Getters and setters
    public String getRideName() { return rideName.get(); }
    public void setRideName(String rideName) { this.rideName.set(rideName); }
    public SimpleStringProperty rideNameProperty() { return rideName; }

    public double getAvgPhLevel() { return avgPhLevel.get(); }
    public void setAvgPhLevel(double avgPhLevel) { this.avgPhLevel.set(avgPhLevel); }
    public SimpleDoubleProperty avgPhLevelProperty() { return avgPhLevel; }

    public double getAvgChlorineLevel() { return avgChlorineLevel.get(); }
    public void setAvgChlorineLevel(double avgChlorineLevel) { this.avgChlorineLevel.set(avgChlorineLevel); }
    public SimpleDoubleProperty avgChlorineLevelProperty() { return avgChlorineLevel; }

    public double getAvgWaterTemp() { return avgWaterTemp.get(); }
    public void setAvgWaterTemp(double avgWaterTemp) { this.avgWaterTemp.set(avgWaterTemp); }
    public SimpleDoubleProperty avgWaterTempProperty() { return avgWaterTemp; }

    public int getTotalViolations() { return totalViolations.get(); }
    public void setTotalViolations(int totalViolations) { this.totalViolations.set(totalViolations); }
    public SimpleIntegerProperty totalViolationsProperty() { return totalViolations; }
}
