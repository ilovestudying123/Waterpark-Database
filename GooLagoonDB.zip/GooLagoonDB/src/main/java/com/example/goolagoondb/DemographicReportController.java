package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;

public class DemographicReportController {

    // TableView and Columns
    @FXML private TableView<DemographicReport> ticketTotalsTable;
    @FXML private TableColumn<DemographicReport, String> RticketTypeColumn;
    @FXML private TableColumn<DemographicReport, Integer> RtotalTypeColumn;

    // BarChart
    @FXML private BarChart<String, Number> ticketTypeGraph;

    // Database credentials
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    // ObservableList for TableView
    private ObservableList<DemographicReport> ticketTotals = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        setupTableColumns();
        loadTicketTotals();
        loadTicketChart();
    }

    private void setupTableColumns() {
        RticketTypeColumn.setCellValueFactory(new PropertyValueFactory<>("ticketType"));
        RtotalTypeColumn.setCellValueFactory(new PropertyValueFactory<>("total"));
        ticketTotalsTable.setItems(ticketTotals);
    }

    private void loadTicketTotals() {
        // Correct SQL query for counting tickets by type
        String sql = "SELECT ticket_type, COUNT(*) AS total FROM ticket GROUP BY ticket_type";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            ticketTotals.clear();
            while (rs.next()) {
                ticketTotals.add(new DemographicReport(
                        rs.getString("ticket_type"),
                        rs.getInt("total")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadTicketChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Tickets");

        for (DemographicReport t : ticketTotals) {
            series.getData().add(new XYChart.Data<>(t.getTicketType(), t.getTotal()));
        }

        ticketTypeGraph.getData().clear();
        ticketTypeGraph.getData().add(series);
    }
}