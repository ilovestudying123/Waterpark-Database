package com.example.goolagoondb;

import java.math.BigDecimal;
import java.sql.Date;

public class QualityInspection{

    private Date date_of_inspection;
    private int ride_no;
    private BigDecimal ph_level;        // DECIMAL
    private BigDecimal chlorine_level;  // DECIMAL
    private BigDecimal water_temp;
    private int violation_count;
    private String violation_desc;

    public QualityInspection(){}

    public QualityInspection(Date date_of_inspection, int ride_no, BigDecimal ph_level, BigDecimal chlorine_level, BigDecimal water_temp, int violation_count, String violation_desc){
        this.date_of_inspection = date_of_inspection;
        this.ride_no = ride_no;
        this.ph_level = ph_level;
        this.water_temp = water_temp;
        this. chlorine_level =  chlorine_level;
        this.violation_count = violation_count;
        this.violation_desc = violation_desc;
    }

    // date_of_inspection
    public Date getDate_of_inspection(){
        return date_of_inspection;
    }
    public void setDate_of_inspection(Date date_of_inspection){
        this.date_of_inspection = date_of_inspection;
    }

    // ride_no
    public int getRide_no(){
        return ride_no;
    }
    public void setRide_no(int ride_no){
        this.ride_no = ride_no;
    }

    // ph_level
    public BigDecimal getPh_level(){
        return ph_level;
    }
    public void setPh_level(BigDecimal ph_level){
        this.ph_level = ph_level;
    }

    // chlorine_level
    public BigDecimal getChlorine_level(){
        return chlorine_level;
    }
    public void setChlorine_level(BigDecimal chlorine_level){
        this.chlorine_level = chlorine_level;
    }

    // water_temp
    public BigDecimal getWater_temp(){
        return water_temp;
    }
    public void setWater_temp(BigDecimal water_temp){
        this.water_temp = water_temp;
    }

    // violation_count
    public int getViolation_count(){
        return violation_count;
    }
    public void setViolation_count(int violation_count){
        this.violation_count = violation_count;
    }

    // violation_desc
    public String getViolation_desc(){
        return violation_desc;
    }
    public void setViolation_desc(String violation_desc){
        this.violation_desc = violation_desc;
    }
}

