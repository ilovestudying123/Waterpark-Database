package com.example.goolagoondb;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import javafx.scene.control.Alert;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;

import java.sql.*;
import java.math.BigDecimal;

public class EmployeeController {

    @FXML
    private TableView<Employee> EmployeeTable;
    @FXML
    private TableColumn<Employee, Integer> employeeNumberColumn;
    @FXML
    private TableColumn<Employee, String> employeeLastNameColumn;
    @FXML
    private TableColumn<Employee, String> employeeFirstNameColumn;
    @FXML
    private TableColumn<Employee, String> jobTitleColumn;
    @FXML
    private TableColumn<Employee, Integer> employeeDepartmentNumberColumn;
    @FXML
    private TableColumn<Employee, Integer> employeePhoneColumn;
    @FXML
    private TableColumn<Employee, BigDecimal> employeeSalaryColumn;
    @FXML
    private TableColumn<Employee, Integer> employeeRideNumberColumn;
    @FXML
    private TableColumn<Employee, Boolean> employeeActiveStatusColumn;

    // Textfields
    @FXML
    private TextField txtEmployeeNumber;
    @FXML
    private TextField txtEmpLastName;
    @FXML
    private TextField txtEmpFirstName;
    @FXML
    private TextField txtJobTitle;
    @FXML
    private TextField txtEmpDepartmentNumber;
    @FXML
    private TextField txtEmpPhone;
    @FXML
    private TextField txtSalary;
    @FXML
    private TextField txtEmpRideNumber;
    @FXML
    private CheckBox chkERActive;

    @FXML
    private TextField txtERSearch;

    private ObservableList<Employee> employees = FXCollections.observableArrayList();

    // DB SETUP
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/waterparkdb";
    private static final String USER = "root";
    private static final String PASS = "12345";

    @FXML
    public void initialize() {
        setupColumns();
        loadEmployeeData();

        EmployeeTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        selectEmployee();
                    }
                }
        );

        // Auto-refresh every 10 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(10), e -> loadEmployeeData()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void setupColumns() {
        employeeNumberColumn.setCellValueFactory(new PropertyValueFactory<>("employee_no"));
        employeeLastNameColumn.setCellValueFactory(new PropertyValueFactory<>("last_name"));
        employeeFirstNameColumn.setCellValueFactory(new PropertyValueFactory<>("first_name"));
        jobTitleColumn.setCellValueFactory(new PropertyValueFactory<>("job_title"));
        employeeDepartmentNumberColumn.setCellValueFactory(new PropertyValueFactory<>("department_no"));
        employeePhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone_number"));
        employeeSalaryColumn.setCellValueFactory(new PropertyValueFactory<>("salary"));
        employeeRideNumberColumn.setCellValueFactory(new PropertyValueFactory<>("ride_no"));
        employeeActiveStatusColumn.setCellValueFactory(new PropertyValueFactory<>("is_active"));

        EmployeeTable.setItems(employees);
    }

    private void loadEmployeeData() {
        employees.clear();

        String sql = "SELECT * FROM employee";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                employees.add(new Employee(
                        rs.getInt("employee_no"),
                        rs.getString("last_name"),
                        rs.getString("first_name"),
                        rs.getString("job_title"),
                        rs.getInt("department_no"),
                        rs.getInt("phone_number"),
                        rs.getBigDecimal("salary"),
                        rs.getInt("ride_no"),
                        rs.getBoolean("is_active")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================================
    // ADD QUALITY INSPECTION
    // ================================
    @FXML
    private void addEmployee() {

        // Required text checks
        if (txtEmpLastName.getText().trim().isEmpty() ||
                txtEmpFirstName.getText().trim().isEmpty() ||
                txtJobTitle.getText().trim().isEmpty())
        {
            showAlert("Missing Input", "First Name, Last Name, and Job Title are required.");
            return;
        }

        Integer employeeNo = parseIntOrNull(txtEmployeeNumber.getText());
        Integer deptNo = parseIntOrNull(txtEmpDepartmentNumber.getText());
        Integer phone = parseIntOrNull(txtEmpPhone.getText());
        Integer rideNo = parseIntOrNull(txtEmpRideNumber.getText());
        BigDecimal salary = parseBigDecimalOrNull(txtSalary.getText());
        boolean isActive = chkERActive.isSelected();

        String sql = """
        INSERT INTO employee 
        (employee_no, last_name, first_name, job_title, department_no, phone_number, salary, ride_no, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, employeeNo);
            ps.setString(2, txtEmpLastName.getText().trim());
            ps.setString(3, txtEmpFirstName.getText().trim());
            ps.setString(4, txtJobTitle.getText().trim());

            // Nullable fields
            if (deptNo == null) ps.setNull(5, java.sql.Types.INTEGER);
            else ps.setInt(5, deptNo);

            if (phone == null) ps.setNull(6, java.sql.Types.INTEGER);
            else ps.setInt(6, phone);

            if (salary == null) ps.setNull(7, java.sql.Types.DECIMAL);
            else ps.setBigDecimal(7, salary);

            if (rideNo == null) ps.setNull(8, java.sql.Types.INTEGER);
            else ps.setInt(8, rideNo);

            ps.setBoolean(9, isActive);

            ps.executeUpdate();
            loadEmployeeData();
            clearFields();
            showAlert("Success", "Employee added.");

        } catch (SQLException e) {
            showAlert("SQL Error", e.getMessage());
        }
    }

    // ================================
// UPDATE EMPLOYEE
// ================================
    @FXML
    private void updateEmployee() {

        if (txtEmployeeNumber.getText().trim().isEmpty()) {
            showAlert("No Selection", "Select an employee from the table first.");
            return;
        }

        Integer deptNo = parseIntOrNull(txtEmpDepartmentNumber.getText());
        Integer phone = parseIntOrNull(txtEmpPhone.getText());
        Integer rideNo = parseIntOrNull(txtEmpRideNumber.getText());
        BigDecimal salary = parseBigDecimalOrNull(txtSalary.getText());
        boolean isActive = chkERActive.isSelected();

        String sql = """
    UPDATE employee
    SET last_name=?, first_name=?, job_title=?, department_no=?, phone_number=?, salary=?, ride_no=?, is_active=?
    WHERE employee_no=?
    """;

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, txtEmpLastName.getText().trim());
            ps.setString(2, txtEmpFirstName.getText().trim());
            ps.setString(3, txtJobTitle.getText().trim());

            // Nullable fields
            if (deptNo == null) ps.setNull(4, java.sql.Types.INTEGER); else ps.setInt(4, deptNo);
            if (phone == null) ps.setNull(5, java.sql.Types.INTEGER); else ps.setInt(5, phone);
            if (salary == null) ps.setNull(6, java.sql.Types.DECIMAL); else ps.setBigDecimal(6, salary);
            if (rideNo == null) ps.setNull(7, java.sql.Types.INTEGER); else ps.setInt(7, rideNo);

            ps.setBoolean(8, isActive);
            ps.setInt(9, Integer.parseInt(txtEmployeeNumber.getText()));

            ps.executeUpdate();

            syncEmpRoleTitle(
                    Integer.parseInt(txtEmployeeNumber.getText()),
                    txtJobTitle.getText().trim()
            );

            loadEmployeeData();
            clearFields();
            showAlert("Success", "Employee updated.");

        } catch (SQLException e) {
            showAlert("SQL Error", e.getMessage());
        }
    }

    // ================================
    // DELETE EMPLOYEE
    // ================================
    @FXML
    private void deleteEmployee() {
        String sql = "DELETE FROM employee WHERE employee_no=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtEmployeeNumber.getText()));
            ps.executeUpdate();

            loadEmployeeData();
            clearFields();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("Input format error: Please select an employee to delete.");
        }
    }

    // ================================
    // CLEAR FIELDS
    // ================================
    @FXML
    private void clearFields() {
        txtEmployeeNumber.clear();
        txtEmpLastName.clear();
        txtEmpFirstName.clear();
        txtJobTitle.clear();
        txtEmpDepartmentNumber.clear();
        txtEmpPhone.clear();
        txtSalary.clear();
        txtEmpRideNumber.clear();
        chkERActive.setSelected(false); // Set checkbox to unchecked
    }

    // ================================
    // SELECT EMPLOYEE FROM TABLE
    // ================================
    private void selectEmployee() {
        Employee employee = EmployeeTable.getSelectionModel().getSelectedItem();
        if (employee == null) return;

        txtEmployeeNumber.setText(String.valueOf(employee.getEmployee_no()));
        txtEmpLastName.setText(employee.getLast_name());
        txtEmpFirstName.setText(employee.getFirst_name());
        txtJobTitle.setText(employee.getJob_title());
        txtEmpDepartmentNumber.setText(String.valueOf(employee.getDepartment_no()));
        txtEmpPhone.setText(String.valueOf(employee.getPhone_number()));
        txtSalary.setText(employee.getSalary().toString());
        txtEmpRideNumber.setText(String.valueOf(employee.getRide_no()));
        chkERActive.setSelected(employee.getIs_active());
    }

    // ================================
    // SEARCH EMPLOYEE
    // ================================
    @FXML
    private void handleSearch() {
        String keyword = txtERSearch.getText().trim();

        if (keyword.isEmpty()) {
            loadEmployeeData();  // reload all employee data
            return;
        }

        employees.clear();

        // Search for the keyword across various columns (Employee #, Name, Job Title, etc.)
        // Note: Using LIKE for string fields and exact match for number fields cast to CHAR
        String sql =
                "SELECT * FROM employee WHERE " +
                        "CAST(employee_no AS CHAR) = ? OR " +
                        "last_name LIKE ? OR " +
                        "first_name LIKE ? OR " +
                        "job_title LIKE ? OR " +
                        "CAST(department_no AS CHAR) = ? OR " +
                        "CAST(phone_number AS CHAR) = ? OR " +
                        "CAST(salary AS CHAR) LIKE ? OR " +
                        "CAST(ride_no AS CHAR) = ? OR " +
                        "CAST(is_active AS CHAR) = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // For exact numeric matches (Employee #, Department #, Phone #, Ride #)
            ps.setString(1, keyword); // employee_no
            ps.setString(5, keyword); // department_no
            ps.setString(6, keyword); // phone_number
            ps.setString(8, keyword); // ride_no
            ps.setString(9, keyword); // is_active (will match '1' or '0' if searched for)

            // For string/partial matches (Last Name, First Name, Job Title, Salary)
            ps.setString(2, "%" + keyword + "%"); // last_name
            ps.setString(3, "%" + keyword + "%"); // first_name
            ps.setString(4, "%" + keyword + "%"); // job_title
            ps.setString(7, "%" + keyword + "%"); // salary

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                employees.add(new Employee(
                        rs.getInt("employee_no"),
                        rs.getString("last_name"),
                        rs.getString("first_name"),
                        rs.getString("job_title"),
                        rs.getInt("department_no"),
                        rs.getInt("phone_number"),
                        rs.getBigDecimal("salary"),
                        rs.getInt("ride_no"),
                        rs.getBoolean("is_active")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ==================================

    private Integer parseIntOrNull(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        return Integer.parseInt(text.trim());
    }

    private BigDecimal parseBigDecimalOrNull(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        return new BigDecimal(text.trim());
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void syncEmpRoleTitle(int empNo, String newTitle) {
        String sql = "UPDATE emp_role SET title=? WHERE employee_no=? AND to_date IS NULL";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newTitle);
            ps.setInt(2, empNo);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}